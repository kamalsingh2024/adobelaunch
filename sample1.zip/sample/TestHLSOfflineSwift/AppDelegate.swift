import UIKit
import CastlabsSDK

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, HLSDownloaderDelegate {

    let streamUrls = [
        "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8",
        "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"
    ]

    var window: UIWindow?
    var downloader = HLSDownloader.shared()
    var reinitialize: Bool = true

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        CastlabsSDK .with([], andLicenseKey: "", andDelegate: nil)

        return true
	}

    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String, completionHandler: @escaping () -> Void) {
        recreateSession()

        print("handleEventsForBackgroundURLSession")
        let wrappedCallback: (() -> Void) = {
            print("handleBackgroundEvents finished")
            completionHandler()
        }

        downloader.handleBackgroundEvents(completionHandler: wrappedCallback)
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        reinitialize = true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.

        if !reinitialize {
            return
        }

        // reinitialize if needed HLSDownloader
        recreateSession()
        reinitialize = false

        startDownloads()
    }

    func recreateSession() {
        downloader = HLSDownloader.shared()
        downloader.delegate = self
        downloader.suspendDownloadsOnEnterBackground = false
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
	}

    func startDownloads() {
        streamUrls.forEach { url in
            startDownload(url)
        }
    }

    func startDownload(_ url: String) {
        downloader.createDownloadRequest(URL(string: url)!, drmConfiguration: nil, userMeta: nil) { (request, error) in

            guard let downloadRequest = request else {
                return
            }

            print(downloadRequest.audioTracks?.options.debugDescription as Any)
            downloadRequest.selectAudioOption((downloadRequest.audioTracks?.options[0])!)
            print(downloadRequest.subtitleTracks?.options.debugDescription as Any)
            downloadRequest.selectSubtitleOption((downloadRequest.subtitleTracks?.options[0])!)

            self.downloader.startDownload(downloadRequest)
        }
    }

    func hlsDownloader(_ downloader: HLSDownloader, didCompleteAllBackgroundDownloadTasks count: UInt) {
        print("didCompleteAllBackgroundDownloadTasks", count)
    }

    func hlsDownloader(_ downloader: HLSDownloader, didCompleteDownloadTask download: HLSDownload, withError error: Error?) {
        print("didCompleteDownloadTask")
    }

    func hlsDownloader(_ downloader: HLSDownloader, didUpdateDownloadTaskState download: HLSDownload) {
        print("didUpdateDownloadTaskState", download.downloadedContentDuration / download.expectedContentDuration * 100)
    }

}

