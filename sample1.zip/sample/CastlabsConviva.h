//
//  NPAWPlugin.h
//  CastlabsSDK
//
//  Created by Guido Parente on 14/06/2016.
//  Copyright © 2016 castLabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#if TARGET_OS_TV
#import "CastlabsTVSDK/CastlabsTVSDK.h"
#else
#import  <CastlabsSDK/CastlabsSDK.h>
#endif

@interface CastlabsConviva : CLAnalyticsSession <CLPlayerListenerProtocol, CLSDKPlugin, CLAdsListener>

@property(nonatomic,assign) int sessionID;

/*!
 @brief  Pass your App specific keys
 @param keys A Conviva specific property map
    @code
    @{
        @"accountCode": @"...",
        @"gatewayUrl": @"..."
    };
 */
- (instancetype)initWithKeys:(NSDictionary *)keys;

@end
