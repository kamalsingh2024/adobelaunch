//
//  CLAdSession.h
//  CastlabsSDK
//
//  Created by Guido Parente on 09/05/2016.
//  Copyright © 2016 castLabs. All rights reserved.
//

#ifndef CLAdSession_h
#define CLAdSession_h
#import <UIKit/UIKit.h>

@class CLAdEvent;
@class CLAdError;
@protocol CLPlayer;

@protocol CLAdsListener <NSObject>
// NSDictionary contains additional info about the loaded ads
//      {
//          "adCuePoints": [] // Array for single ads with cue time in seconds (double value)
//      }
-(void) adsLoaded:(NSDictionary*) adsData;
-(void) adStarted:(CLAdEvent*) event;
-(void) adStopped:(CLAdEvent*) event;
-(void) didRequestContentPause;
-(void) didRequestContentResume;
@optional
-(void) adLoaded:(CLAdEvent*) event;
-(void) adEvent:(CLAdEvent*) event;
-(void) adError:(CLAdError *)error;

@end

@interface CLAdSession : NSObject

/**
 *  Play only ad breaks scheduled after time.
 */
@property (nonatomic, assign) NSTimeInterval playAdsAfterTime;

/**
 *  The stream request API key. It's configured through the
 *  <a href="//support.google.com/dfp_premium/answer/6381445">
 *  DFP Admin UI</a> and provided to the publisher to unlock their content.
 *  It verifies the applications that are attempting to access the content.
 */
@property(nonatomic, copy) NSString *apiKey;


- (id) initWithPlayer:(id<CLPlayer>) player
         forViewController:(UIViewController*) vc
                                  onView:(UIView*) view;

- (void)requestAds:(NSString*)url;
- (void)requestAdsWithAdsResponse:(NSString *)adsResponse;
/**
 *  Starts advertisement playback.
 */
- (void)start;

/**
 *  Pauses advertisement.
 */
- (void)pause;

/**
 *  Resumes the advertisement.
 */
- (void)resume;

/**
 *  Skips the advertisement.
 */
- (void)skip;

/**
 *  Causes the ads manager to stop the ad and clean its internal state.
 */
- (void)destroy;

/**
 *  If an ad break is currently playing, discard it and resume content.
 *  Otherwise, ignore the next scheduled ad break.
 */
- (void)discardAdBreak;

// Code for initing the plugin
typedef CLAdSession* (*CLAdSessionFactoryFunction)(void);
+(CLAdSession*) createAdSession;
+(void) setFactoryFunction:(CLAdSessionFactoryFunction) func;

@end


#endif /* CLAdSession */
