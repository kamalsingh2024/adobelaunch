//
//  CLLog.h
//  CastlabsSDK
//
//  Created by Guido Parente on 14/03/2019.
//  Copyright © 2019 castLabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <os/log.h>

#ifndef kCFCoreFoundationVersionNumber_iOS_10_0
    #define kCFCoreFoundationVersionNumber_iOS_10_0 1348
#endif

#define isIOS10orGreater (kCFCoreFoundationVersionNumber >= kCFCoreFoundationVersionNumber_iOS_10_0)

#ifdef __cplusplus
extern "C" {
#endif
    os_log_t CLLog(os_log_type_t type);
    bool CLCheckLogTap(os_log_type_t level, NSString *format, ...);
#ifdef __cplusplus
}
#endif

#define cl_log(format, ...) do { \
 if (CLCheckLogTap(OS_LOG_TYPE_DEFAULT, @format, ##__VA_ARGS__)) { \
    if (kCFCoreFoundationVersionNumber >= kCFCoreFoundationVersionNumber_iOS_10_0) { \
        os_log(CLLog(OS_LOG_TYPE_DEFAULT), format, ##__VA_ARGS__) ;\
     } else {\
        NSLog(@format, ##__VA_ARGS__); \
    } \
 } \
} while(0)

#define cl_log_error(format, ...) do { \
  if (CLCheckLogTap(OS_LOG_TYPE_ERROR, @format, ##__VA_ARGS__)) { \
     if (kCFCoreFoundationVersionNumber >= kCFCoreFoundationVersionNumber_iOS_10_0) { \
         os_log_error(CLLog(OS_LOG_TYPE_ERROR), format, ##__VA_ARGS__) ;\
      } else {\
         NSLog(@format, ##__VA_ARGS__); \
     } \
  } \
 } while(0)
