//
//  HLSLicenseMetadata.h
//  CastlabsSDK
//
//  Created by Guido Parente on 02/10/2018.
//  Copyright © 2018 castLabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CastlabsSDK/FairplayLicenseListener.h>

NS_ASSUME_NONNULL_BEGIN

@class CLDrmConfiguration;

@interface HLSLicenseMetadata : NSObject

-(id _Nonnull) initWithUrl:(NSString* ) url;

@property CLDrmConfiguration* drmConfig;
@property bool shouldPersistKeys;
@property NSString* trackingToken;
@property NSString* contentUrl;
@property NSURL* keyUrl;

- (bool) isDrmToday;

- (NSString*) getSkdUri;

- (nullable NSString*) getAssetId;
- (nullable NSString*) getVariantId;
- (nullable NSString*) getKeyId;

@end

NS_ASSUME_NONNULL_END
