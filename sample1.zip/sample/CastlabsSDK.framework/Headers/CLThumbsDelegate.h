//
//  CLThumbsDelegate.h
//  CastlabsSDK
//
//  Created by Mackode - Bartlomiej Makowski on 22/02/2019.
//  Copyright © 2019 castLabs. All rights reserved.
//

#ifndef CLThumbsDelegate_h
#define CLThumbsDelegate_h

#import <CoreMedia/CoreMedia.h>
#import <CastlabsSDK/CastlabsSDK.h>

/*!
 @protocol  CLThumbsDelegate

 @brief Custom thumbnails delegate

 @discussion This is a delegate for setting, generatin and getting custom thumbnails

 @author castLabs
 @copyright  Copyright © 2019 castLabs
 */
@protocol CLThumbsDelegate <NSObject>

@optional

/**
 * @brief Called (on background thread) when the player wants a thumbnail for a given time
 *
 * @param timestamp Timestamp of requested thumbnail
 *
 */
- (CLThumb* _Nullable) getThumb:(CMTime) timestamp;

@end

#endif /* CLThumbsDelegate_h */
