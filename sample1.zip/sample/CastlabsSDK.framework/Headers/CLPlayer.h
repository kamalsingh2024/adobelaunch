#ifndef CLPlayer_h
#define CLPlayer_h

#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>

@protocol PlayerListenerProtocol;
@protocol CLAdsListener;
@protocol CLImageDownloader;
@protocol CLThumbsDelegate;
@protocol CLPlayerListenerProtocol;

@class CLAdError;
@class CLDrmConfiguration;
@class SubtitlesView;
@class CLGridThumbnail;
@class CLPLayerTrack;
@class CLThumb;
@class CLSubtitlesStyle;
@class CLContentMetadata;
@class CLPlayerSubtitleTrack;
@class CLPlayerVideoTrack;
@class CLPlayerAudioTrack;
@class CLVideoTrackQuality;
@protocol CLAnalyticsDelegate;
@class CLAnalyticsSession;

typedef NS_ENUM(NSInteger, StateID);
typedef NS_ENUM(NSInteger, ErrorID);

typedef NS_ENUM(NSUInteger, CLContentType) {
    kContentHLS = 1,
    kContentDASH = 2,
    kContentSmoothStreaming = 3,
    kContentMP4 = 4,
    kContentPIFF = 5,
    kContentRemoteMP4 = 6,
    kContentMP3 = 7,
    kContentRemoteMP3 = 8,
    kContentOther = 100,
    kContentUnknown = 101,
};

typedef NS_ENUM(NSUInteger, CLSubtitleFormat) {
    kSubtitleTTML = 1,
    kSubtitleWebVTT = 2,
    kSubtitleSRT = 3,
    kSubtitleUnknown = 4
};

typedef NS_ENUM(NSUInteger, CLLicenseResult) {
    kLicenseResultOk = 0,           /// Operation is successful
    kLicenseNotFetched = 1,         /// Failed: license hasn't been fetched yet
    kLicenseNotSupported = 2,       /// Failed: operation is not supported
    kLicenseInvalidArgument = 1000  /// Failed: passed invalid argument
};

typedef NS_ENUM(NSInteger, ChaseLiveEdge) {
    kChaseLiveEdgeDisabled = 0,     /// Disables live edge chasing
    kChaseLiveEdgeSkipFrames,       /// Makes player skip frames to get closer to the live edge.
    kChaseLiveEdgeSpeedupPlayback   /// Makes player increase playback rate to chase live edge.
};

static NSString *_Nonnull const kPlaybackTypeVod = @"vod";         /// Stream is VOD
static NSString *_Nonnull const kPlaybackTypeLive = @"live";       /// Stream is Live
static NSString *_Nonnull const kPlaybackTypeUnknown = @"unknown"; /// Stream type is unknown

NS_ASSUME_NONNULL_BEGIN

/*!
 @brief An audio tap that gets read-only access to audio buffers
 @param format The format of the audio buffers
 @param numberFrames The number of sample frames that will be rendered
 @param timeStamp The audio timestamp
 @param flags A bitmask of AudioQueueProcessingTapFlags
 @param buffers The audio buffers that are about to be played
 @return YES if audio should be played normally through the internal audio queue, NO if it should be silenced
 @discussion
    When the player audio queue is initialized (i.e. on playback start and when the application enters foreground
    after being put in background), the callback will be invoked with a valid format parameter but 0 frames, no flags and
    invalid timeStamp and buffers. Subsequent invokations will use the same format and provide actual samples.
    The audio tap receive the samples after effects (e.g. playbackVolume) have been applied
 */
typedef BOOL (^CLAudioTap)(const AudioStreamBasicDescription *format,
                           UInt32 numberFrames,
                           const AudioTimeStamp  *timeStamp,
                           UInt32 flags,
                           const AudioBufferList *buffers);

/*!
 @protocol  CLPlayer
 
 @brief Player controller API
 
 @discussion This controller implementation allows you to control and manage the video player instance and receive feedback from it.
 An instance of this class can be obtained using the factory methods of CLPlayerFactory
 @see CLPlayerFactory
 @author castLabs
 @copyright  Copyright © 2015 castLabs
 */
@protocol CLPlayer <NSObject>
@required

/*!
 @brief Opens the given URL to the video.
 @discussion The player will start to load the resources and when it's ready
 will change the status of playback to STATE_READY
 @return true if no error occurred, false otherwise
 */
- (BOOL) open;

/*!
 @brief Start playback.
 @discussion The player must be in STATE_READY or STATE_PAUSED for this to have effect
 @remark Must be called after [open]
 @return true if no error occurred, false otherwise
 */
- (BOOL) play;

/*!
 @brief Pause playback.
 @discussion The player must be in STATE_PLAYING or STATE_STALLED for this to have effect.
 */
- (void) pause;

/*!
 @brief Stop playback and release resources
 @discussion After calling this, you need to allocate the player again if you want to restart playback
 */
- (void) stop;

/*!
 @brief Seek to desired time
 @discussion The player might not be able to seek exactly to your desired time and will choose the closest earlier frame. Once the seek operation completes the player will transition to STATE_READY.
 @param time Time to seek
 */
- (void) seek:(CMTime) time;

/*!
 @brief Returns the number of audio tracks
 @return NSUInteger Number of audio tracks
 */
- (NSUInteger) numberOfAudioTracks;

/*!
 @brief Returns a textual description of an audio track
 @param index Audio track index
 @return CLPlayerTrack Description of audio track or nil if the index is not found
 */
- (CLPlayerAudioTrack* _Nullable ) describeAudioTrack:(NSUInteger)index;

/*!
 @brief Returns current audio track index
 @return NSUInteger Current audio track index
 */
- (NSUInteger) currentAudioTrackIndex;

/*!
 @brief Returns the number of subtitle tracks
 @return NSUInteger Number of subtitle tracks
 */
- (NSUInteger) numberOfSubtitlesTracks;

/*!
 @brief Returns a textual description of an subtitle track
 @param index Subtitle track index
 @return CLPlayerTrack Description of subtitle track or nil if the index is not found
 */
- (CLPlayerSubtitleTrack* _Nullable) describeSubtitleTrack:(NSInteger)index;

/*!
 @brief Returns information about the video track along with the available qualities
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer]
 */
- (CLPlayerVideoTrack* _Nonnull) describeVideoTrack;

/*!
 @brief Select a fixed video quality or -1 to disable manual selection
 
 @discussion The list of qualities can be retrieved from [describeVideoTrack].qualities. Calling this method before [player play] forces playback to start from that quality. If the method is used throughout the playback you may experience a small delay for the change to take effect.
 
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer]
 */
- (void) selectVideoQuality:(int) quality;

/*!
 @brief Current fullness of the video buffer
 @return The fullness in seconds
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer]
 */
- (Float64) videoFullness;

/*!
 @brief Current fullness of the audio buffer
 @return The fullness in seconds
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer]
 */
- (Float64) audioFullness;

/*!
 @brief Returns the selected video track quality or -1 if no quality was selected
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer]
 */
- (int) getSelectedVideoQuality;

/*!
 @brief Returns playback type (live, vod, unknown)
 @return NSString * Current stream playback type
 */
- (NSString *) getPlaybackType;

/*!
 @brief Returns session id which is connected to CLPlayer instance lifecycle
 @return NSString * Current session id
 @remark The value stays the same as long as CLPlayer instance exists
 */
- (NSString *) getSessionId;

/*!
 @brief Returns current subtitle track index
 @return NSUInteger Current subtitle track index
 */
- (NSInteger) currentSubtitleTrackIndex;

/*!
 @brief Select audio track
 @param index Adio track index
 */
- (void) selectAudioTrack:(NSUInteger)index;

/*!
 @brief Select subtitle track
 @param index Subtitle track index
 */
- (void) selectSubtitleTrack:(NSInteger)index;

/*!
 @brief Disable current subtitles (if any)
 */
-(void) disableSubtitles;

/*!
 @brief Side-load subtitles content from a URL.
    Downloads and parses the subtitles content (if a supported format types).
    Creates a new subtitle track appended after any existing subtitle tracks.
 @discussion  This requires the Subtitles Plug-in.
    Subtitle tracks exist only during playback, therefore this function can only create tracks during that time-frame.
 @param url location of the subtitle content file
 @param subtitleFormat Format of subtitle
 @param displayName label of a subtitle
 @param languageCode string defined in <a href="https://www.ietf.org/rfc/rfc5646.txt">RFC5646</a>
 @return Track Index or -1 if failed
 @remark The player must be at least in STATE_READY for this to have effect
 */
-(size_t) addSubtitlesTrackFromUrl:(nonnull NSURL*)url
                        withFormat:(CLSubtitleFormat)subtitleFormat
                   withDisplayName:(nullable NSString*)displayName
                  withLanguageCode:(nullable NSString*) languageCode;

/*!
 @brief Set max supported resolution.
 @param width max width supported
 @param height max height supported
 @remark Must be called before [open]
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer]
 */
-(void) setMaxResolutionWithWidth: (int) width andHeight:(int) height;

/*!
 @brief Download license for current asset
 @discussion If the license was succesfully loaded the event EVENT_LICENSE_LOADED will be triggered from callback CLPlayerListenerProtocol::onEvent:
    If an error will occur, the event CL_ERROR_DRM_ERROR will be triggered from callback CLPlayerListenerProtocol::onError:
 */
- (void) prefetchLicense;

/*!
 @brief Remove cached license
 @discussion If the license was succesfully removed the event EVENT_LICENSE_REMOVED will be triggered from callback CLPlayerListenerProtocol::onEvent:
    If an error will occur, the event CL_ERROR_DRM_ERROR will be triggered from callback CLPlayerListenerProtocol::onError:
 */
- (void) deleteLicense;

/*!
 @brief Retrieve license renewal period for current asset
 @discussion The license renewal period can be retrieved only once the license is fetched
    The Fairplay license examination is not supported yet. After the license renewal period runs off the license is considered expired and must be renewed
 @param  handler License renewal period. Nil expiration with successful result
    means no renewal period for license
 */
- (void) licenseRenewalPeriod:(void (^)(NSDate* _Nullable date, NSError * _Nullable error, CLLicenseResult result))handler;

/*!
 @brief Check for downloaded Fairplay License
 */
-(bool) fairplayLicenseExists;

/*!
 @brief Fairplay Rental License - Remaining play duration in seconds
 */
-(long) fairplayLicensePlayDurationLeft;

/*!
 @brief Fairplay Rental License - Remaining storage duration in seconds
 */
-(long) fairplayLicenseStorageDurationLeft;

/*!
 @brief Current playback position
 */
@property (nonatomic, assign) CMTime position;

/*!
 @brief Total playback time
 */
@property (nonatomic, readonly) CMTime duration;

/*!
 @brief Playback start position in milliseconds
 */
@property (nonatomic, assign) CMTime startPosition;

/*!
 @brief Seeking ranges (for live streams)
 */
@property (nonatomic, readonly)  NSArray<NSValue *> * __nullable seekableTimeRanges;

/*!
 @brief True if player is in STATE_PLAYING
 */
@property (readonly) BOOL isPlaying;

/*!
 @brief True if player is in STATE_FINISHED
 */
@property (readonly) BOOL isEnded;

/*!
 @brief Adjust minimal possible seek time in seconds. Default: 0
 */
@property (nonatomic, assign) int64_t preferredLiveSeekMin;

/*!
 @brief Custom Subtitle Style
 */
@property CLSubtitlesStyle* __nullable subtitleStyle;

/*!
 @brief Current list of player listeners
 */
@property NSPointerArray* _Nullable playerListeners;

/*!
 @brief Offset between audio and video. Negative values make audio play earlier, positive values make it play later.
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
@property (nonatomic, assign) CMTime avOffset;

/*!
 @brief Add a player listener
 */
- (void)addListener:(nonnull __weak id<CLPlayerListenerProtocol>)listener;

/*!
 @brief Remove a player listener
 */
- (void)removeListener:(nonnull __weak id<CLPlayerListenerProtocol>)listener;

/*!
 @brief Current player state
 */
@property (readonly) StateID state;

/*!
 @brief Player layer
 */
@property (readonly) CALayer* _Nonnull playerView;

/*!
 @brief Video content size
 */
- (CGSize)getVideoContentSize;

/*!
 @brief canvas size
 */
- (CGSize)getCanvasSize;

/*!
 @brief Indicates whether the player allows playback of HD content The default value is YES.
 @remark Must be called before [open]
 */
@property (nonatomic) BOOL HDenabled;

/*!
 @brief Indicates whether the player should seek exactly to the required seeking position (default) or to the beginning of the corresponding segment.
 
 @discussion Using the former will always start playback from the requested time, never rendering any samples
    before that time (but decoding if necessary). A drawback of this is that the perceived time it
    takes to seek may increase a bit from the users perspective and that it may cause buffer
    starvation under low bandwidth conditions (because the samples not rendered are read as fast as
    possible).
 
    The latter will start playback at the first frame of the corresponding segment. The drawback here is
    that the user won't get the exact requested time.
 
 @remark Works only for content *not* played with native player. Content played with native player always seek to the required position. See [CLPlayerFactory preferNativePlayer].
 @remark Must be called before [open] */
@property (nonatomic) BOOL secondPrecisionSeeking;

/*!
 @brief Indicates whether the player should continue the playback in the background. The default value is NO.
 @discussion Besides setting this flag to 'true' please add the UIBackgroundModes key in your app's Info.plist file. Its value is an array that contains one or more strings that identify which background tasks   your application supports. Specify the string value "audio"
 @remark Works only for audio-only streams
 @remark Init the shared AVAudioSession with [setCategory:AVAudioSessionCategoryPlayback]
 @remark Must be called before [open]
 */
@property (nonatomic) BOOL continuePlaybackInTheBackground;

/*!
 @brief Information about current video quality
 */
@property (readonly) CLVideoTrackQuality* _Nonnull quality;

/*! @brief Returns underlining AVPLayer
 @remark Works only for HLS stream
 @remark Should be used for debugging purpose mainly. Using this object to modify the playback may lead to unexpected and conflicting behaviour with our API.
 */
@property (readonly) AVPlayer* _Nullable avPlayer;

/*!
 @brief Returns underlining SubtitlesView
 @remark Works only for DASH and SmoothStreaming streams
 @remark Use the view if you want to try customizing the subtitles yourself but be aware that we will not provide support for this
 */
@property (readonly, weak) SubtitlesView* _Nullable subtitlesView;

/*!
 @brief DRM Configuration
*/
@property (readonly) CLDrmConfiguration* _Nullable drmConfiguration;

/*!
 @brief Indicates whether the player should hold the STATE_READY event until the selected subtitle track is loaded. The default value is NO.
 @discussion You can use the [player selectSubtitleOption:] before calling [player open] to preselect the subtitle track
 
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 @remark Must be called before [open]
 */
@property bool playbackWaitsUntilSubtitlesLoad;

/*!
 @brief Pause playback when an audio device (either wired or wireless) is disconnected
 
 @remark Default value is NO.
 */
@property bool pausePlaybackWhenHeadphonesAreDisconnected;

/*!
 @brief Metadata for the current item. This information are used by different plugins (analytics, chromecast)
 @remark Must be called before [open]
 */
@property  CLContentMetadata* _Nullable metadata;

/*!
 @brief Array of registered analytics sessions
 */
@property NSMutableArray<CLAnalyticsSession*>* _Nullable analyticsSessions;

/*!
 @brief Optional delegate for defining extra behaviour into analytics session
 */
@property(nonatomic) id<CLAnalyticsDelegate> _Nullable analyticsDelegate;

/*!
 @brief The player is able to start automatically the Analytics session but it must be stopped manually with this method
 */
-(void) stopAnalyticsSession;

/*!
 @brief Current list of ADs Listeners
 */
@property NSPointerArray* _Nullable adsListeners;

/*!
 @brief Add Ad Listener
 */
- (void)addAdListener:(nonnull __weak id<CLAdsListener>)listener;

/*!
 @brief Remove Ad Listener
 */
- (void)removeAdListener:(nonnull __weak id<CLAdsListener>)listener;

/*!
 @brief Custom headers for HTTP requests
*/
-(void) setCustomHTTPHeaders:(nonnull NSDictionary*) headers;

/*!
 @brief Current content url to play
 */
@property (readonly) NSString* _Nonnull manifestUrl;

/*!
 @brief In the case of downloaded stream, you can set with this property the original manifest url
 */
@property NSString* _Nonnull originalManifestUrl;

/*!
 @brief Video gravity determines how the video content is scaled or stretched within the player bounds
 @remark Default value is AVLayerVideoGravityResizeAspect
 */
@property (copy) AVLayerVideoGravity _Nonnull videoGravity;

/*!
 @brief Video gravity determines how the video content is scaled or stretched within the player bounds
 @remark Default value is AVLayerVideoGravityResizeAspect
 @param  videoGravity The player layer supports the following video gravity values: * AVLayerVideoGravityResizeAspect - player should preserve the video’s aspect ratio and fit the video within the bounds, * AVLayerVideoGravityResizeAspectFill - player should preserve the video’s aspect ratio and fill the bounds, * AVLayerVideoGravityResize - video should be stretched to fill the bounds
 */
-(void) setVideoGravity:(nonnull AVLayerVideoGravity) videoGravity;

/*!
 @brief A value of 1.0 (default) plays the current item at its natural rate. Setting to values lower than 1 slow down the playback; values higher than 1 speed it up
 @remark Content *not* played with native player mute for rates != 1
 @remark Expects frame drops for high values
 @remark Must be called after [play]
 @remark AirPlay playbackRate values above 2.0 are not permitted
 */
@property float playbackRate;

/*!
 @brief The playback volume for the audio queue (used by custom Player), ranging from 0.0 through 1.0 on a linear scale. A value of 0.0 indicates silence; a value of 1.0 (the default) indicates full volume for the audio queue instance.
 @remark This value does not impact the device overall volume. Setting it at 1.0 (default) means: "play at the device current max volume"
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 @remark Must be called after the player transitions to STATE_READY
 */
@property float playbackVolume;

/*!
 @brief The average level meter for current playing audio channels (kAudioQueueProperty_CurrentLevelMeter)
 @remark This is indipendent from the current device volume
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(float) getCurrentAvgLevelMeter;

/*!
 @discussion Custom protocol scheme that is used by the player to trigger a Fairplay request. The default values is `skd` but it can be overwrtitten using this property
 */
@property NSString* _Nonnull fairplayScheme;

/*!
 @discussion Optional configuration for Chromecast
 @param url Stream url
 @param configuration DRM configuration
 @param contentType Stream content type
 @param subtitles Array of NSString subtitles urls; this parameter overrides side loaded subtitles from the player. This value default is nil and no or all player's side-loaded subtitles will be used, if set will override side-loaded subtitles for Chromecast. Each array elements contains NSDictionary with keys (and NSString values): url, displayName, format, languageCode (track's RFC 1766 language code). CustomSubtitles helper class can be used to create proper list of subtitles
 @param languageCode Preferred subtitle language code to start when casting
 */
-(void) setManifestUrlForChromecast:(nonnull NSString*) url
                andDrmConfiguration:(nullable CLDrmConfiguration*) configuration
                     andContentType:(CLContentType) contentType
                 andCustomSubtitles:(nullable NSArray *)subtitles
       andPreferredSubtitleLanguage:(nullable NSString*) languageCode;

/*!
 @brief Manifest URL to be send to Chromecast device
 @discussion This value default to manifestUrl unless a different value is specified using [setMAnifestUrlForChromecast:andDrmConfiguration]
 @remark Fairplay streams will fail to play on Chromecat
 */
@property NSString* _Nonnull manifestUrlForChromecast;

/*!
 @brief DRM Configuration to be send to Chromecast device
 @discussion This value default to drmConfiguration unless a different value is specified using [setManifestUrlForChromecast:andDrmConfiguration]
 @remark Fairplay streams will fail to play on Chromecat
 */
@property CLDrmConfiguration* _Nullable drmConfigurationForChromecast;

/*!
 @brief Content type to be send to Chromecast device
 @discussion This value default to contentType unless a different value is specified using [setMAnifestUrlForChromecast:andDrmConfiguration]
 @remark Fairplay streams will fail to play on Chromecat
 */
@property  CLContentType contentTypeForChromecast;

/*!
 @brief Custom subtitles list to be sent to Chromecast
 @discussion This value default is nil and no or all player's side-loaded subtitles will be used, if set will override side-loaded subtitles for Chromecast. Each array elements contains NSDictionary with keys (and NSString values): url, displayName, format, languageCode (track's RFC 1766 language code). CustomSubtitles helper class can be used to create proper list of subtitles.
 */
@property NSArray * _Nullable subtitlesForChromecast;

/*!
 @brief Preferred language for Chromecast
*/
@property NSString* _Nullable preferredSubtitleLanguageForChromecast;

/*!
 @brief Native player will use interception methods to parse HLS playlist and segments manually.
 @discussion Native player gives an option for loading content related data using resouce loader.
 
 @remark Works only for HLS streams with native player.
 @remark Used to gather additional information from HLS playlist (e.g. codecs).
 If enabled the following variables will be available:
 - CLVideoTrackQuality codec
 - CLPlayerAudioTrack codec
 - CLPlaybackInfo audioCodec, videoCodec
 @remark Default value is NO.
 */
@property (nonatomic) BOOL useContentInterception;

/*!
 @brief Set the bitrate above which video qualities will be ignored
 @discussion Default: 0
 Needs to be called before [open] otherwise it won't have any effect
 Does not apply when using AVPlayer or for local files
 Use 0 to disable filtering by bytrate
 */
-(void) setMaxBitrate: (int64_t) bitPerSec;

/*!
 @brief The bitrate above which video qualities will be ignored
 */
-(int64_t) getMaxBitrate;

/*!
 @brief Set a bandwidth estimate that will be used to choose the first downloaded segments
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 @discussion You can use this function to pre-seed the adaptation algorithm with information about available bandwidth
 before it can compute a reliable estimate. Use 0 to use the download speed of the manifest as an intial
 estimate
 */
-(void) setInitialBandwidthEstimate:(int64_t)bitPerSec;

/*!
 @brief A bandwidth estimate that will be used to choose the first downloaded segments
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(int64_t) getInitialBandwidthEstimate;

/*!
 @brief Minimum buffer required until playback begins
 @remark WARNING works only for DASH and SmoothStreamin streams
 */
-(void) setMinPrebufferTime:(double)seconds;

/*!
@brief Returns Minimum buffer required until playback begins (default: 6 seconds)
 */
-(double) minPrebufferTime;

/*!
 @brief Minimum buffer required after buffer underruns
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setMinRebufferTime:(double)seconds;

/*!
@brief Returns Minimum buffer required after buffer underruns (default: 12 seconds)
 */
-(double) minRebufferTime;

/*!
 @brief Maximum buffer size allowed (default: 60 seconds). When filled to maximum, new downloads will be paused
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setMaxPrebufferTime:(double)seconds;

/*
 @brief Returns Maximum buffer size allowed (default: 6 seconds)
 */
-(double) maxPrebufferTime;

/*!
 @brief Initial live latency target - how many seconds before the live edge the playback should start (default: 10 seconds).
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setLiveEdgeDelay:(double)seconds;

/*!
 @brief Returns Initial live latency target - how many seconds before the live edge the playback should start (default: 10 seconds).
*/
-(double) liveEdgeDelay;

/*!
 @brief Set player view in given controller
 @param vc The ViewController where to set the player view
 @param bounds The size and position there the player view should be set
 */
- (void) setInViewController:(nonnull UIViewController*) vc inBounds:(CGRect) bounds;

/*!
 @brief Fine grain video player listener
 @discussion It triggers detailed events about video track playback. Should be mainly used for debugging purpose.
 @param listener Video player listener
 */
-(void) addVideoListener:(nonnull id<PlayerListenerProtocol>)listener;

/*!
 @brief Fine grain audio player listener
 @discussion It triggers detailed events about audio track playback. Should be mainly used for debugging purpose.
 @param listener Audio player listener
 */
-(void) addAudioListener:(nonnull id<PlayerListenerProtocol>)listener;

#if !TARGET_OS_TV
/*!
 @brief Returns an already initiliazed AVPictureInPictureController
 @remark Works only for content played with native player. See [CLPlayerFactory preferNativePlayer].
 @remark From our tests, the PiP playback becomes available on most devices when the player moves to STATE_PLAYING
 */
-(AVPictureInPictureController* _Nullable) getPictureInPictureController;
#endif

/*!
 @brief Setter for custom thumbnails
*/
- (void) setThumbnailsWithArray:(nonnull NSArray<CLThumb*>*) thumbs andDownloader:(nonnull __weak id<CLImageDownloader>) downloader;

/*!
 @brief Set thumbnails delegate. Delegate methods will be called for every thumb needed
 @param thumbsDelegate Thumbnails delegate
 */
-(void)setThumbnailDelegate:(id<CLThumbsDelegate>)thumbsDelegate;

/*!
 @brief Set a master thumbnails image
 @param gridThumb Master thumbnail image
 */
-(void) setThumbnailWithGridResource:(nonnull CLGridThumbnail*)gridThumb;

/*!
 @brief Retrieve thumbnails from a ROKU BIF file
 @discussion https://sdkdocs.roku.com/display/sdkdoc/Trick+Mode+Support
 @param path Either a local BIF file path or a remote URL
 */
-(void) setThumbnailWithBifFile:(nonnull NSString*)path;

/*!
 @brief Retrieve thumbnails encoded in a WebVTT format
 @param path Either a local file path or a remote URL
 */
-(void) setThumbnailWithWebVTTtrack:(nonnull NSString *)path;

/*!
 @brief Returns the corresponding thumbnail for the given timestamp
 @param timestamp Time
 @return CLThumb Thumbnail for the given timestamp or nil if the thumbnail was not found
 */
- (CLThumb * _Nullable)getThumb:(CMTime)timestamp;

@property (readonly) CLContentType contentType;

/*!
 @brief Enable to make player attempt to move as closer to live edge as possible.
 Default is kChaseLiveEdgeDisabled
 */
@property ChaseLiveEdge chaseLiveEdge;

/*!
 @brief Maximum time to stay behind live edge, seconds
 Default is 10.0
 */
@property Float64 chaseLiveEdgeCatchupThreshold;

/*!
 @brief Nominal time to stay behind live edge, seconds
 Default is 5.0
 */
@property Float64 chaseLiveEdgeCutoffThreshold;

/*!
 @brief Duration of HLS segment, seconds
 Used with kChaseLiveEdgeSkipFrames and HLS streams.
 Default is 10.0
 */
@property Float64 chaseLiveEdgeHLSSegmentDuration;

/*!
 @brief Playback speed increase
 Used with kChaseLiveEdgeSpeedupPlayback
 Default is 1.1
 */
@property Float64 chaseLiveEdgeSpeedupRatio;

/*!
 @brief Informs the player that this content is protected but without using DRM.
 @discussion When set to `true` the player ignores the fact that content is protected but DRM configuration is missing and relies on default OS API for retrieving the key. This is useful when you play HLS content protected with standard transport encryption (https://tools.ietf.org/html/draft-pantos-hls-rfc8216bis-05#section-4.4.2.4)
 
 Default is `false`
 */
@property bool protectedWithoutDRM;

/*!
 @brief An audio tap that will receive a read only copy of stream audio
 @remark Must be set before calling [open]
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
@property  CLAudioTap audioTap;

/*!
 @brief The connection timeout for network requests
 */
-(long long) getRequestConnectTimeout;

/*!
 @brief Set the connection timeout for network requests. Default: 2000ms
 */
-(void) setRequestConnectTimeout:(long long) ms;

/*!
 @brief The connection timeout for manifest requests
 */
-(long long) getManifestConnectTimeout;

/*!
 @brief Set the connection timeout for manifest requests. Default: -1ms
 @discussion If the value is <= 0, setRequestConnectTimeout will be used.
 */
-(void) setManifestConnectTimeout:(long long) ms;

/*!
 @brief The connection timeout for segment requests
 */
-(long long) getSegmentConnectTimeout;

/*!
 @brief Set the connection timeout for segment requests. Default: -1ms
 @discussion If the value is <= 0, setRequestConnectTimeout will be used.
 */
-(void) setSegmentConnectTimeout: (long long) ms;

/*!
 @brief The time after a request which is not receiving data will be aborted
 */
-(long long) getRequestReadTimeout;

/*!
 @brief Set the time after a request which is not receiving data will be aborted. Default: 5000ms
 */
-(void) setRequestReadTimeout:(long long) timeout;

/*!
 @brief The time after a manifest request which is not receiving data will be aborted
 */
-(long long) getManifestReadTimeout;

/*!
 @brief Set the time after a manifest request which is not receiving data will be aborted. Default: -1 ms
 @discussion If the value is <= 0, setRequestReadTimeout will be used.
 */
-(void) setManifestReadTimeout:(long long) timeout;

/*!
 @brief The time after a segment request which is not receiving data will be aborted
 */
-(long long) getSegmentReadTimeout;

/*!
 @brief Set the time after a segment request which is not receiving data will be aborted. Default: -1ms
 @discussion If the value is <= 0, setRequestReadTimeout will be used
 */
-(void) setSegmentReadTimeout:(long long) timeout;

/*!
 @brief The maximum number of attempts a network request will be tried
 */
-(void) setMaxRequestAttempts:(int) attempts;

/*!
 @brief Set the maximum number of attempts a network request will be tried. Default: 3
 */
-(int) getMaxRequestAttempts;

/*!
 @brief The maximum number of attempts a manifest network request will be tried
 */
-(void) setMaxManifestAttempts:(int) attempts;

/*!
 @brief Set the maximum number of attempts a manifest network request will be tried. Default: -1
 @discusison If the value is <= 0, setMaxRequestAttempts will be used.
 */
-(int) getMaxManifestAttempts;

/*!
 @brief The maximum number of attempts a segment network request will be tried
 */
-(void) setMaxSegmentAttempts:(int) attempts;

/*!
 @brief Set the maximum number of attempts a segment network request will be tried. Default: -1
 @discussion If the value is <= 0, setMaxRequestAttempts will be used.
 */
-(int) getMaxSegmentAttempts;

/*!
 @brief The initial delay applied to the first retry for network requests
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(long long) getRequestRetryBaseDelay;

/*!
 @brief Set the initial delay applied to the first retry for network requests. Default: 1000ms
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setRequestRetryBaseDelay:(long long) ms;

/*!
 @brief The initial delay applied to the first retry for manifest network requests
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(long long) getManifestRetryBaseDelay;

/*!
 @brief Set the initial delay applied to the first retry for manifest network requests. Default: -1ms
 @remark If the value is <= 0, setRequestRetryBaseDelay will be used.
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setManifestRetryBaseDelay:(long long) ms;

/*!
 @brief The initial delay applied to the first retry for segment network requests
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(long long) getSegmentRetryBaseDelay;

/*!
 @brief Set the initial delay applied to the first retry for segment network requests. Default: -1ms
 @remark If the value is <= 0, setRequestRetryBaseDelay will be used.
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setSegmentRetryBaseDelay:(long long) ms;

/*!
 @brief The multiplication factor for the delay applied after the first retry
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(double) getRequestRetryBackoffFactor;

/*!
 @brief Set the multiplication factor for the delay applied after the first retry. Default: 2.0
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setRequestRetryBackoffFactor:(double) factor;

/*!
 @brief The fuzz factor for the delay
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(double) getRequestRetryFuzzFactor;

/*!
 @brief Set the fuzz factor for the delay. Default: 0.5
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setRequestRetryFuzzFactor:(double) ms;

/*!
 @brief The maximum delay applied to retries for network requests
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(long long) getRequestRetryMaxDelay;

/*!
 @brief Set the maximum delay applied to retries for network requests. Default: 5000ms
 @remark Works only for content *not* played with native player. See [CLPlayerFactory preferNativePlayer].
 */
-(void) setRequestRetryMaxDelay:(long long) ms;

/// On supported devices Picture in Picture starts automatically when player is put in the background.
/// Set this flag to true to disable this behaviour
@property(nonatomic) bool disablePictureInPicture;

/// We activate/deactivate automatically AVAudioSession when the player is allocated/released
/// Set this flag to false to disable this behaviour
@property(nonatomic) bool automanagedAVAudioSession;

@end

NS_ASSUME_NONNULL_END

#endif /* CLPlayer_h */
