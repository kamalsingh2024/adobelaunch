//
//  CLFileDownloaderInterface.h
//  CastlabsSDK
//
//  Created by Guido Parente on 21/10/2019.
//  Copyright © 2019 castLabs. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CLFileDownloaderInterface : NSObject

typedef CLFileDownloaderInterface* _Nonnull (*d_FactoryFunction)(void);
+(nullable CLFileDownloaderInterface*) createDownloader;
+(void) setFactoryFunction:(d_FactoryFunction) func;

@end

NS_ASSUME_NONNULL_END
