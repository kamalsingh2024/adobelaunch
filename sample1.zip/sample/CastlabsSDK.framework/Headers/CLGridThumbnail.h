//
//  CLGridThumbnail.h
//  CastlabsSDK
//
//  Created by Guido Parente on 18/01/2017.
//  Copyright © 2017 castLabs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLGridThumbnail : NSObject

@property NSString *url;        // Grid image URL
@property int gridHeight;       // Number of columns
@property int gridWidth;        // Number of rows
@property int timeMs;           // Grid elements time difference / Thumb duration
@property int maxIndex;         // Number of grid images

@end
