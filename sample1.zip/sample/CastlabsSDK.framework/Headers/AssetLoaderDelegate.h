//
//  AssetLoaderDelegate.h
//  CastlabsSDK
//
//  Created by Iskandar Safarov on 26/11/2015.
//  Copyright © 2015 castLabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol FairplayLicenseListener;
@class HLSLicenseMetadata;

/**
 * This class implements the AVAssetResourceLoaderDelegate and it's used to:
 * - load OMA and Fairplay keys referenced in HLS Playlists,
 * - intercept and parse HLS manifest requests (e.g. to get codecs information). Interception
 *  is optional (CLPlayer useContentInterception)
 *
 * For iOS 11.3 and higher keys loading was separated by Apple and the newer API
 * AVContentKeySessionDelegate is preferable to load OMA and Fairplay keys.
 *
 * For more information please refere to:
 * https://developer.apple.com/documentation/avfoundation/avassetresourceloader
 *
 */
@interface AssetLoaderDelegate : NSObject <AVAssetResourceLoaderDelegate>

@property (nullable) AVAssetResourceLoadingRequest *loadingRequest;
@property (nullable, nonatomic) id<FairplayLicenseListener> licenseLoaderListener;
@property (nonnull) NSString* fairplayScheme;
@property (nullable, nonatomic) NSArray *masterPlaylist;

-(instancetype _Nullable )initWithLicenseMetadata:(HLSLicenseMetadata* _Nonnull) metadata;
-(BOOL)prefetchOMAKeyWithError:(NSError* _Nullable * _Nullable)error;
-(NSURL *_Nonnull)proxyStreamUrl:(NSURL * _Nonnull)streamUrl andChangeSchemeToProxy:(BOOL)append;
-(void)prefetchManifest:(NSURL * _Nonnull)streamUrl;
-(void)updateLicenseMetadata:(HLSLicenseMetadata* _Nonnull) metadata;

@end
