#import <Foundation/Foundation.h>
#import <os/log.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, SDKEvent)  {
    /// Suspected Jailbroken detected
    SDK_ERROR_JAILBROKEN = -1,
    SDK_ERROR_UNKNOWN = -1000,
};

typedef NS_ENUM(NSInteger, SDKLogLevel) {
    LogLevelDefault = 0,              // Default logs
    LogLevelError = 1,                // Only error logs
    LogLevelNone = -1                 // No logs
};

/*!
@brief A log tap that receives all SDK logs
@param level The log severity
@param message The log message
@return Whether the message should be also sent to the system log
*/
typedef BOOL (^CLLogTap)(SDKLogLevel level, NSString *message);

/* See the enum SDKEvent above for the events thrown by this delegate*/
@protocol CastlabsSDKDelegate  <NSObject>
    -(void) onError:(SDKEvent)error withDetails:(NSData* _Nullable) data;
@end

/*!
 @interface  CastlabsSDK
 
 @brief castLabs SDK API
 @discussion Initialization methods and other utilies
 
 @author castLabs
 @copyright  Copyright © 2015 castLabs
 */
@interface CastlabsSDK : NSObject

/*!
	@brief Init the SDK
	@discussion This function should be called before any other.\n Only the first call to this method is honored. Subsequent calls are no-ops.

	@param licenseKey License key as a string
	@return BOOL if no error occurred, false otherwise
 */
+ (BOOL) init:(NSString*) licenseKey;

/*!
	@brief Init the SDK
	@discussion This function should be called before any other.\n Only the first call to this method is honored. Subsequent calls are no-ops.
	@param plugins Array of plugin to be enabled
	@param licenseKey License key as a string
    @param delegate (optional) listener for asynch SDK messages. Keep the delegate instance for the entire app lifecycle
	@return BOOL if no error occurred, false otherwise
 */
+ (BOOL) with:(NSArray*)plugins
        andLicenseKey:(NSString*) licenseKey
        andDelegate: ( nullable id<CastlabsSDKDelegate>) delegate;
	
/*! True if the SDK was initialized correctly */
+ (BOOL) isInitialized;

/*! Returns a human readable SDK version string */
+(NSString*) version;

/*! Returns a human readable SDK player name string */
+(NSString*) playerName;

/* WARNING experimental feature */
+(void) enableM3U8protocolHandler;

/*! Remove all cached licenses */
+(void) clearCache;

/*! Set desired log level */
+(void) setLogLevel:(SDKLogLevel) level;

/*! Return current log level */
+(SDKLogLevel) getLogLevel;

/*! Return the current log tap  */
+(CLLogTap) getLogTap;

/*!
 * @brief Set a log tap
 * @remark Must be called before initializing the SDK
 */
+(void) setLogTap:(CLLogTap) tap;
@end

NS_ASSUME_NONNULL_END
