#ifndef CustomSubtitles_h
#define CustomSubtitles_h

#import <Foundation/Foundation.h>
#import "CLPlayer.h"

/*!
 @interface  CustomSubtitles

 @brief Domain class for passing custom subtitles configuration

 @author castLabs
 @copyright  Copyright © 2019 castLabs
 */
@interface CustomSubtitles : NSObject

/// Add custom subtitles to array
-(void) addCustomSubtitleWithUrl:(NSString *)url andDisplayName:(NSString *)displayName andFormat:(CLSubtitleFormat)format andLanguageCode:(NSString *)languageCode;

/// Generate a list of custom subtitles
-(NSArray *)list;

@end

#endif
