#ifndef CLPlayerListenerProtocol_h
#define CLPlayerListenerProtocol_h

#if !TARGET_OS_TV
#import <CastlabsSDK/CastlabsSDK.h>
#else
#import <CastlabsTVSDK/CastlabsTVSDK.h>
#endif

typedef NS_ENUM(NSInteger, EventID);

@class CLPlaybackInfo;

/*!
 @protocol  CLPlayerListenerProtocol
 
 @brief Player Listener API
 
 @discussion This is a high level listener interface that provides callbacks for events from a video player.
 
 @author castLabs
 @copyright  Copyright © 2015 castLabs
 */
@protocol CLPlayerListenerProtocol <NSObject>

@optional

/**
 * @brief Called when the player state changes
 *
 * @param newState The new state
 * @param oldState The old state
 * @param data Additional optional params
 *  - for STATE_SEEKING:{seekTo:val} requested seek time in seconds
 */
- (void) onStateChangedTo:(StateID)newState from:(StateID)oldState withData:(NSDictionary*)data;

/**
 * @brief Called when the player state changes
 *
 * @param newState The new state
 * @param oldState The old state
 * @param data Additional optional params
 *  - for STATE_SEEKING:{seekTo:val} requested seek time in seconds
 * @param sender Sender object
 */
- (void) onStateChangedTo:(StateID)newState from:(StateID)oldState withData:(NSDictionary*)data andSender:(id)sender;

/**
 * @brief Called in case of a special event
 *
 * @param eventID The event ID
 */
- (void) onEvent:(EventID) eventID;

/**
 * @brief Called when the video quality changes
 *
 */
- (void) onQualitySwitch:(CLVideoTrackQuality*) quality;

// Called when it's time to display a thumbnail
- (void)onThumbnail:(CLThumb*) thumb;

/**
 * @brief Called when a new auth token is required because the cached one is invalid
 *
 */
- (NSString*) onAuthTokenRequired;

/**
 * @brief This callback can be used to provide a custom SPC message to the KeyServer
 *
 */
- (NSString*)getSPCMessageToKeyServer:(NSString*) spcData;

/**
 * @brief This callback can be used to extract the CKC data from a custom Key Server Response
 *        to an request containg the SPC message
 *
 */
- (NSData*)getCKC:(NSData*) keyServerResponse;

/**
 * @brief Routinely called to inform listener about playback info
 *
 */
- (void) onPlaybackInfo:(CLPlaybackInfo*) info;

/**
 * @brief Called when the player finished loading thumbnails
 *
 * @param success equals NO when loading was interrupted
 */
- (void) onThumbnailsReady:(BOOL) success;

@required

/**
 * @brief Called in case of an error
 *
 * @param errorID The error ID
 * @param message The error description
 */
- (void) onError:(ErrorID) errorID withMessage:(NSString*) message;

@end

#endif /* CLPlayerListenerProtocol_h */
