#ifndef CLPlayerTrack_h
#define CLPlayerTrack_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, StateID);

@interface CLVideoTrackQuality: NSObject

@property (nonatomic, assign) long long bitrate;
@property (nonatomic, assign) int width;
@property (nonatomic, assign) int height;
@property (nonatomic, copy) NSString *codec;
@property (nonatomic, assign) float framerate;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

@interface CLPlaybackInfo: NSObject

@property (nonatomic, strong) CLVideoTrackQuality* trackQuality;
@property (nonatomic, strong) CLVideoTrackQuality* downloadedTrackQuality;
@property (nonatomic, assign) double videoBuffer;
@property (nonatomic, assign) double audioBuffer;
@property (nonatomic, assign) StateID playbackState;
@property (nonatomic, assign) long long lastDownloadBps;
@property (nonatomic, assign) float playbackRate;
@property (nonatomic, assign) NSUInteger audioChannels;
@property (nonatomic, copy) NSString *audioCodec;
@property (nonatomic, copy) NSString *videoCodec;

@end

@interface CLPlayerTrack : NSObject

/// Map of roles
@property(nonatomic) NSDictionary<NSString*, NSArray<NSString*>*> * roles;

/// FourCC describing track format. May be 0 if unset.
@property (nonatomic) FourCharCode formatCode;

/// String describing track format. Automatic if formatCode is set.
@property (nonatomic, nullable)  NSString* format;

/// String with track title.
@property (nonatomic, nullable) NSString* title;

@end

@interface CLPlayerVideoTrack: CLPlayerTrack

@property NSMutableArray<CLVideoTrackQuality*>* qualities;

@end

@interface CLPlayerTrackWithLanguageAndIndex : CLPlayerTrack

/// RFC 5646 language code.
@property (nonatomic, nullable) NSString* languageCode;

/// String describing language.
// If the languageCode property is set, this property gives a text representation of the language code
// using the default Locale
@property (nonatomic, nullable) NSString* language;

/// The index is derived from the order in which they appear in the manifest
@property (nonatomic) NSInteger trackIndex;

@end

@interface CLPlayerAudioTrack: CLPlayerTrackWithLanguageAndIndex

/// Number of audio channels
@property (nonatomic) NSUInteger numChannels;

/// Audio codec
@property (nonatomic, copy) NSString *codec;

@end

typedef NS_ENUM(NSInteger, CLPlayerSubtitleTrackType) {
	SUBTITLE = 0,
	CAPTION = 1,
};

@interface CLPlayerSubtitleTrack: CLPlayerTrackWithLanguageAndIndex

/// Indicates a Forced subtile track.
/// This attribute is always false for all types different than CLPlayerTrackTypeText
@property (nonatomic) BOOL forced;

/// NSURL with subtitle track url / track specific url.
/// In current implementation it is used only for side-loaded
/// subtitles. In the future it can handle any track specific Url
@property (nonatomic, nullable) NSURL *url;

/// Each text track is marked as type Subtitle by default.
/// However the ClosedCaption type will be identified in these two cases
/// 1. Dash Streams. The corresponding <AdaptationSet> must have the following <Role> element
///		<Role schemeIdUri="urn:mpeg:dash:role::2011" value="caption"/>
/// 2. HLS Streams. The corresponding #EXT-X-MEDIA must have the following TYPE attribute
///		TYPE=CLOSED-CAPTIONS
@property (nonatomic) CLPlayerSubtitleTrackType type;

@end

NS_ASSUME_NONNULL_END
#endif /* CLPlayerTrack_h */
