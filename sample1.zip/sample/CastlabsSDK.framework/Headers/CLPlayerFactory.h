#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol CLPlayer;
@class CLDrmConfiguration;
@class CLContentMetadata;
typedef NS_ENUM(NSUInteger, CLContentType);

/*!
 @interface  CLPlayerFactory
 
 @brief Factory methods for initializing player
 
 @discussion The methods of this class must be used to get an instance of our player
 
 @author castLabs
 @copyright  Copyright © 2015 castLabs
 */
@interface CLPlayerFactory : NSObject


/*!
@brief Whether to use the native video player when possible. Default: true.

@discussion
 CLPlayer uses two different players under the hood: one "native" (based on AVPlayer) and one "custom" (based on VideoToolbox). Certain formats are only playable by one of those while others are supported by both.
   - HLS+Fairplay: only native
   - DASH, SmoothStreaming: only custom
   - HLS, HLS+ClearKey, MP4, MP3: both
 This flag instructs what player engine is used for the common formats
 When choosing the engine please pay attention what features you want to support as some of them are only available on one of them
    - Native: Airplay, Picture in Picture
    - Custom: Widevine, ABR settings, AudioTap and other custom features (refers to the methods in CLPlayer for the complete list)

@remark Needs to be set before any create-method is called to have an effect.
*/
@property BOOL preferNativePlayer;

/*!
 @brief Create an instance of the player
 @param url Stream url
 @return CLPlayer An instance of the player
 @remark Make sure alloc/init or new has been called previously, not just alloc.
 */
-(id<CLPlayer>) createPlayerWithStreamUrl:(NSString*) url
                    andContentType:(CLContentType) contentType;

/*!
 @brief Create an instance of the player
 @param url Stream url
 @param configuration DRM configuration
 @param contentType Stream content type
 @return CLPlayer An instance of the player
 @remark Make sure alloc/init or new has been called previously, not just alloc.
 */
-(id<CLPlayer>) createPlayerWithStreamUrl:(NSString*) url
                      andDrmConfiguration:(CLDrmConfiguration*) configuration
                           andContentType:(CLContentType) contentType;

/*!
 @brief Create an instance of the player for 360 degree playback
 @param url Stream url
 @param configuration DRM configuration
 @param output GL connection
 @param contentType Stream content type
 @return CLPlayer An instance of the player
 */
-(id<CLPlayer>) createPlayerWithStreamUrl:(NSString*) url
                andDrmConfiguration:(CLDrmConfiguration*) configuration
                and360Output:(AVPlayerItemVideoOutput*) output
                andContentType:(CLContentType) contentType;

/*!
 @brief Create an instance of the player
 @param url Stream url
 @param configuration DRM configuration
 @param metadata Content metadata will be used by analytics plugins (if present)
     @code
         @{
         @media: {
             @"title": "content title", //required
             @"isLive: @YES,            //required
         },
         @"extraParams": @{
             @"param1": @"Extra param 1 value",
             @"param2": @"Extra param 2 value"
         }
     }
 @param contentType Stream content type
 @return CLPlayer An instance of the player
 @remark Make sure alloc/init or new has been called previously, not just alloc.
 */
-(id<CLPlayer>) createPlayerWithStreamUrl:(NSString*) url
                      andDrmConfiguration:(CLDrmConfiguration*) configuration
                       andContentMetadata:(CLContentMetadata*) metadata
                           andContentType:(CLContentType) contentType;

/*!
 @brief Create an instance of the player
 @param filePath A local MP4 file path
 @param contentType Stream content type
 @return CLPlayer An instance of the player
 @remark Make sure alloc/init or new has been called previously, not just alloc.
 */
-(id<CLPlayer>) createPlayerWithLocalFilepath:(NSString*) filePath
                          andDrmConfiguration:(CLDrmConfiguration*) configuration
                            andContentType:(CLContentType) contentType
__attribute__((deprecated("Please use createPlayerWithStreamUrl:")));

/*!
 @brief Create an instance of the player
 @param videoPath A local video file path
 @param audioPath A local audio file path
 @param configuration DRM configuration
 @param contentType Stream content type
 @return CLPlayer An instance of the player
 @remark Make sure alloc/init or new has been called previously, not just alloc.
 */
-(id<CLPlayer>)createPlayerWithLocalVideopath:(NSString*) videoPath
                                    audioPath:(NSString*) audioPath
                          andDrmConfiguration:(CLDrmConfiguration*) configuration
                               andContentType:(CLContentType) contentType;

@end
