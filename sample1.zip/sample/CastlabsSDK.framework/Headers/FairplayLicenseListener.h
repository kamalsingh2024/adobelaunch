//
//  FairplayLicenseListener.h
//  CastlabsSDK
//
//  Created by Guido Parente on 02/05/2018.
//  Copyright © 2018 castLabs. All rights reserved.
//

#ifndef FairplayLicenseListener_h
#define FairplayLicenseListener_h

NS_ASSUME_NONNULL_BEGIN

@protocol FairplayLicenseListener <NSObject>

- (void) onFairplayLicenseLoaded:(bool)res withError:(NSError*_Nullable) err;

@optional
- (nonnull NSString*) onAuthTokenRequired;
- (nullable NSString*)getSPCMessageToKeyServer:(NSString*) spcData;
- (nullable NSData*)getCKC:(NSData*) keyServerResponse;

@end

NS_ASSUME_NONNULL_END

#endif /* FairplayLicenseListener_h */
