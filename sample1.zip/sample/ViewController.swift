//
//  ViewController.swift
//
//  Created by Criz on 21.10.20.
//
import Foundation
import CastlabsSDK
import CastlabsDASH
import CastlabsOMA
import CastlabsStreamDownloader
import UIKit

// in seconds
let PLAY_DURATION_LIMIT = 60.0
let EXPIRATION_DELAY = 10 * 60.0


class ViewController: UIViewController, CLMovieDownloadSetDelegate, CLPlayerListenerProtocol {
    let downloader = CLMovieDownloader.shared()
    var fetchers: [Fetcher] = []
    var content: [String: CLDrmConfiguration] = [:]
    let fetchersPoolCount = 1

    static var runningFetchers = 0
    static var fetchedLicenses = 0

    var drm: CLDrmConfiguration?
    var player: CLPlayer?
    var playerView: UIView?

    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var releaseButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let key = ""
        
        CastlabsSDK .with([CastlabsOMA(), CastlabsDASH(), CastlabsStreamDownloader()],
                          andLicenseKey: key,
                          andDelegate: nil);

        if (CLMovieDownloader.shared().downloadedMovies == nil) || CLMovieDownloader.shared().downloadedMovies!.count == 0 {
            playButton.isHidden = true
            releaseButton.isHidden = true
        }

        playerView = UIView(frame: CGRect.init(x: 20, y: 30, width: UIScreen.main.bounds.width - 40, height: UIScreen.main.bounds.height / 3))
        playerView?.backgroundColor = .lightGray
        view.addSubview(playerView!)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"

        let url = "..."
        let playDuration = Int(PLAY_DURATION_LIMIT)
        let expirationDelay = EXPIRATION_DELAY
        let absoluteExpiration = formatter.string(from: Date().addingTimeInterval(expirationDelay))

        drm = CLDrmConfiguration()
        drm?.persistLicense = true
        drm?.assetId = "..."
        drm?.merchantId = "..."
        drm?.environment = .production
        drm?.workingDirectory = self.getDocumentsDirectory() + "/OMA/DRM"
        drm?.type = .oma

        /// do not fetch the license again (remove the app to do it)
        /// use persisted license (OMA handles this)
        if (CLMovieDownloader.shared().downloadedMovies != nil) && CLMovieDownloader.shared().downloadedMovies!.count > 0 {
            return
        }

        drm?.sessionId = "crtjson:{\"profile\": {\"rental\": {\"playDuration\": \(playDuration * 1000), \"absoluteExpiration\": \"\(absoluteExpiration)\"}}, \"storeLicense\": true, \"outputProtection\": {\"digital\": false, \"analogue\": false, \"enforce\": false}, \"assetId\": \"offline_test_content\"}"

        self.createDirectory(drm!.workingDirectory)
        self.content[url] = drm
        let fetcher = Fetcher(url, drm!)
        fetchers.append(fetcher)

        downloader.fetchDownloadSet(forURL: url) { (set, error) in
            if let set = set {
                set.selectAllQualities()
                set.delegate = self
                self.downloader.download(set)
            } else if let error = error {
                print("⚠️ fetchDownloadSet failed with error \(error)")
            }
        }

        /// fetch all the licenses
        while (ViewController.fetchedLicenses < 1) {
            if (ViewController.runningFetchers < fetchersPoolCount && fetchers.count > 0) {
                fetchers[ViewController.fetchedLicenses].fetchLicense()
                ViewController.runningFetchers += 1
            }
        }
    }

    @IBAction func startPlaying(_ sender: Any) {
        let factory = CLPlayerFactory()

        let movies = CLMovieDownloader.shared().downloadedMovies
        let path = movies?.first?.localURL
        player = factory.createPlayer(withStreamUrl: path, andDrmConfiguration: drm, andContentType: .contentDASH)

        player?.addListener(self)
        player?.open()
    }

    @IBAction func releasePlayer(_ sender: Any) {
        player?.stop()
        player?.removeListener(self)
        player?.playerView.removeFromSuperlayer()
        player = nil
    }
    
    func movieDownloadSet(_ set: CLMovieDownloadSet, didUpdate progress: CLDownloadProgress) {
        print("\(progress.value * 100)", separator: " ", terminator: " ")
    }

    func movieDownloadSet(_ set: CLMovieDownloadSet, didCompleteWithError error: Error?) {
        if (error == nil) {
            let url = (set.movie.parent?.url)!
            print("✅ movieDownloadSet didComplete ", url)
            DispatchQueue.main.async {
                self.playButton.isHidden = false
                self.releaseButton.isHidden = false
            }
            print("sessionId \(drm?.sessionId ?? "")")
        } else {
            print("⚠️ movieDownloadSet failed with error \(error!)")
        }
    }

    func onStateChanged(to newState: StateID, from oldState: StateID, withData data: [AnyHashable : Any]!) {
        if (newState == StateID.STATE_READY) {
            playerView!.layer.addSublayer(player!.playerView)
            player!.playerView.frame = playerView!.bounds
            player?.play()
        }
    }

    func onError(_ errorID: ErrorID, withMessage message: String!) {
        print("⚠️ CLPlayerListenerProtocol onError \(errorID) with message \(message ?? " none")")
    }

    func createDirectory(_ path: String) {
        do {
            try FileManager.default.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
        } catch {
            print("Unable to create directory \(error)")
        }
    }

    func getDocumentsDirectory() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
}

class Fetcher: NSObject, CLPlayerListenerProtocol {
    let url : String
    let drm : CLDrmConfiguration
    var player : CLPlayer?
    
    init(_ url : String, _ drm : CLDrmConfiguration) {
        self.url = url
        self.drm = drm
        player = CLPlayerFactory.init().createPlayer(withStreamUrl: url, andDrmConfiguration: drm, andContentType: .contentDASH)
        super.init()
    }
    
    func fetchLicense() {
        print("⬇️ fetching license for url \(url)")
        player?.addListener(self)
        player?.prefetchLicense()
    }
    
    func onEvent(_ eventID: EventID) {
        switch eventID {
        case .EVENT_LICENSE_LOADED:
            print("✅ license fetched ", url)
            player?.stop()
            player = nil
            ViewController.fetchedLicenses += 1
            ViewController.runningFetchers -= 1
        default:
            print("CLPlayerListenerProtocol onEvent \(eventID)")
        }
    }
    
    func onError(_ errorID: ErrorID, withMessage message: String!) {
        print("⚠️ CLPlayerListenerProtocol onError \(errorID) with message \(message ?? " none")")
    }
}

extension ErrorID {
    var loc: String {
        switch self {
        case .CL_ERROR_DOWNLOAD:
            return "CL_ERROR_DOWNLOAD Player has failed to retrieve the decryption key for the current content. It is usually caused by a misconfiguration of the CLDRMConfiguration object."
        case .CL_ERROR_DRM_ERROR:
            return "CL_ERROR_DRM_ERROR Player license is invalid or expired. Please contact support if you see this error unexpectedly. Note that if this error occurs, playback is prevented and the player will stop working"
        case .CL_ERROR_LICENSE:
            return "CL_ERROR_LICENSE Opening the stream has failed. It can be thrown in case of an unsupported stream type or malformed stream url."
        case .CL_ERROR_OPEN_STREAM:
            return "CL_ERROR_OPEN_STREAM The DRM key for the current content has expired"
        case .CL_ERROR_DRM_LICENSE_EXPIRED:
            return "CL_ERROR_DRM_LICENSE_EXPIRED"
        case .CL_ERROR_AUDIO_DECODE_ERROR:
            return "CL_ERROR_AUDIO_DECODE_ERROR The current content is not allowed to play on an external screen"
        case .CL_ERROR_SECOND_SCREEN_DETECTED:
            return "CL_ERROR_SECOND_SCREEN_DETECTED The DRM key for the current content can not be retrieved"
        case .CL_ERROR_DRM_NO_LICENSE:
            return "CL_ERROR_DRM_NO_LICENSE The current content is not allowed to be screen recorded"
        case .CL_ERROR_SCREEN_RECORDING_DETECTED:
            return "CL_ERROR_SCREEN_RECORDING_DETECTED License has expired because of too many concurrent usages"
        case .CL_ERROR_DRM_CONCURRENT_STREAMING_EXCEEDED:
            return "CL_ERROR_DRM_CONCURRENT_STREAMING_EXCEEDED License was not found because server returned internal error"
        case .CL_ERROR_DRM_SERVER_INTERNAL_ERROR:
            return "CL_ERROR_DRM_SERVER_INTERNAL_ERROR DRM Configuration is missing required asset ID"
        case .CL_ERROR_MISSING_ASSET_ID:
            return "CL_ERROR_MISSING_ASSET_ID URL is malformed"
        case .CL_ERROR_MALFORMED_URL:
            return "CL_ERROR_MALFORMED_URL Fairplay certificate is missing"
        case .CL_ERROR_MISSING_APP_CERTIFICATE:
            return "CL_ERROR_MISSING_APP_CERTIFICATE Persistable key was not found in cache"
        case .CL_ERROR_MISSING_PERISTABLE_KEY:
            return "CL_ERROR_MISSING_PERISTABLE_KEY Method is not available with current API"
        case .CL_ERROR_MISSING_API:
            return "CL_ERROR_MISSING_API"
        case .CL_ERROR_UNKNOWN:
            return "CL_ERROR_UNKNOWN"
        case .CL_ERROR_NO_ERROR:
            return "CL_ERROR_NO_ERROR"
        default:
            return "ERROR"
        }
    }
}

extension URLSession {
    func synchronousDataTask(with url: URL) -> (Data?, URLResponse?, Error?) {
        var data: Data?
        var response: URLResponse?
        var error: Error?

        let semaphore = DispatchSemaphore(value: 0)

        let request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalAndRemoteCacheData, timeoutInterval: 10)
        let dataTask = self.dataTask(with: request) {
            data = $0
            response = $1
            error = $2

            semaphore.signal()
        }
        dataTask.resume()

        _ = semaphore.wait(timeout: .distantFuture)

        return (data, response, error)
    }
}

public extension String {
    func between(_ left: String, _ right: String) -> String? {
        guard
            let leftRange = range(of: left), let rightRange = range(of: right, options: .backwards)
            , leftRange.upperBound <= rightRange.lowerBound
        else { return nil }

        let sub = self[leftRange.upperBound...]
        let closestToLeftRange = sub.range(of: right)!
        return String(sub[..<closestToLeftRange.lowerBound])
    }

    var length: Int {
        get {
            return self.count
        }
    }

    func substring(to : Int) -> String {
        let toIndex = self.index(self.startIndex, offsetBy: to)
        return String(self[...toIndex])
    }

    func substring(from : Int) -> String {
        let fromIndex = self.index(self.startIndex, offsetBy: from)
        return String(self[fromIndex...])
    }

    func substring(_ r: Range<Int>) -> String {
        let fromIndex = self.index(self.startIndex, offsetBy: r.lowerBound)
        let toIndex = self.index(self.startIndex, offsetBy: r.upperBound)
        let indexRange = Range<String.Index>(uncheckedBounds: (lower: fromIndex, upper: toIndex))
        return String(self[indexRange])
    }

    func character(_ at: Int) -> Character {
        return self[self.index(self.startIndex, offsetBy: at)]
    }
}
