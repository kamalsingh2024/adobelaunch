// !WARNING!
// * The source code of this class is given out to customers and referenced in our docuemntation.
//		Any change to this class must be coordinate with the rest of the team.
// * This class follows Doxygen convetions for documentation

#ifndef CLPlayerViewController_h
#define CLPlayerViewController_h

#import <UIKit/UIKit.h>
#import <CastlabsSDK/CastlabsSDK.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, CLSubtitlesDisplayMode) {
    kSubtitleDisplayModeNone,               // Do not make any automatic subtitle selection
    kSubtitleDisplayModeOnlyForced,         // Automatically show only forced subtitle for the preferred text language
    kSubtitleDisplayModePreferredLanguage,  // Automatically show subtitles for the preferred text language
};

@class CLDrmConfiguration;
@class CustomSubtitles;
@class CLPlayerTrack;
@class CLPlaybackInfo;

@protocol CLPlayerViewControllerDelegate <NSObject>
@optional
- (void) didDismissPlayerViewController:(UIViewController*)vc;
- (void) onViewWillTransitionToSize:(CGSize)size;
- (void) onShareButton:(id)sender;
/// onViewDidAppear is called after the `player` initialization
- (void) onViewDidAppear;
- (void) onPlayerViewControllerTapped;
- (void) onToggleControlsVisibility:(bool) controlVisible;
- (nullable NSString*) onAuthTokenRequired;
- (nullable NSString *)textForTrackDescription:(CLPlayerTrack *)trackDescription;
- (void) onPlaybackInfo:(CLPlaybackInfo*) info;
- (NSData *)getCKC:(NSData *)keyServerResponse;
- (NSString *)getSPCMessageToKeyServer:(NSString *)spcData;
@end

/*!
 @interface  CLPlayerViewController
 
 @brief Sample ViewController using castLabs player
 
 @discussion It can be used to launch the player in full-screen mode. The source code of this class is provided to SDK customer as part of the bundle.
 
 @author castLabs
 @copyright  Copyright © 2015 castLabs
 */
@interface CLPlayerViewController : UIViewController

/// Stream url to be played
@property(nullable, nonatomic) NSString* streamUrl;

/// Original asset's configuration Url
@property(nullable, nonatomic) NSString* assetConfigurationUrl;

/// DRM configuration should be provied for encrypted files
@property(nullable, nonatomic) CLDrmConfiguration* drmConfiguration;

/// The player can guess the protocol type from the stream URL but you can also set it explicitely with this property
@property(nonatomic) CLContentType contentType;

/// Text to be displayed on a upper-left overlay (besides the logo). Hidden by default.
@property(nullable, nonatomic) NSString* debugText;

/// Enable loop playback
@property(nonatomic) bool loopEnabled;

/// On supported devices Picture in Picture starts automatically when player is put in the background.
/// Set this flag to true to disable this behaviour
@property(nonatomic) bool disablePictureInPicture;

/// Automatically hide playback controls on tap. Default: true
@property(nonatomic) bool autoHideControls;

/// When `autoHideControls` is true and the user tap on the screen, we hide playback controls and show logo and some debug information. Set this flag to true to hide them. Default: false
@property(nonatomic) bool hideLogoAndDebugInfo;

/// Auto-hide the home bar indicator (if possible). Default: true
@property(nonatomic) bool preferAutoHideHomeIndicator;

/*!
@brief Whether to use the native video player when possible. Default: true.

@discussion
 CLPlayer uses two different players under the hood: one "native" (based on AVPlayer) and one "custom" (based on VideoToolbox). Certain formats are only playable by one of those while others are supported by both.
   - HLS+Fairplay: only native
   - DASH, SmoothStreaming: only custom
   - HLS, HLS+ClearKey, MP4, MP3: both
 This flag instructs what player engine is used for the common formats
 When choosing the engine please pay attention what features you want to support as some of them are only available on one of them
    - Native: Airplay, Picture in Picture
    - Custom: Widevine, ABR settings, AudioTap and other custom features (refers to the methods in CLPlayer for the complete list)

@remark Needs to be set before the view controller is presented
*/
@property(nonatomic) bool preferNativePlayer;

/// Define automatic subtitle selection. Default: kSubtitleDisplayModeOnlyForced
@property(nonatomic) CLSubtitlesDisplayMode subtitleMode;

/// Preferred language for subtitle and closed-captions track
// Value expressed as language codes defined in RFC 5646
@property(nullable, nonatomic) NSString* preferredTextLanguage;

/// Enable ads playback
@property(nullable, nonatomic) NSString* adsServer;

/// Enable ads playback for Chromecast
@property(nullable, nonatomic) NSString* adsServerForChromecast;

/// Playback start position in milliseconds
@property(nonatomic) long startPosition;

/// Logo (150x32) to be displayed in the upper-left corner. Hidden by default
@property(nullable, nonatomic) UIImage* logoImage;

/// castLabs cms ID
@property(nullable, nonatomic) NSString* cmsId;

/// Optional delegate for defining extra behaviour into analytics session
@property(nullable, nonatomic) id<CLAnalyticsDelegate> analyticsDelegate;

@property(nullable, nonatomic, readonly) id<CLPlayer> player;

/// Custom protocol scheme that is used by the player to trigger a Fairplay request. The default values is `skd` but it can be overwrtitten using this property
@property(nullable) NSString* fairplayScheme;

/// Show an Airplay button besides the player controls. Hidden by default
@property bool showAirplayButton;

/// Switch off AirPlay after player is closed. Default value false
@property bool turnOffAirplayOnClose;

/*!
	@brief Side-load subtitles content from a URL.
	Downloads and parses the subtitles content (if a supported format types).
	Creates a new subtitle track appended after any existing subtitle tracks.
	@discussion  This requires the Subtitles Plug-in.
	The Subtitles Plug-in is not currently used for local files.
	Subtitle tracks exist only during playback, therefore this function
	can only create tracks during that time-frame.
	@param url Location of the subtitle content file
    @param format The subtitle format
    @param displayName The name displayed for subtitle track
    @param languageCode The language code
 */
- (void) addSubtitlesTrackFromUrl:(NSURL*)url
                       withFormat:(CLSubtitleFormat)format
                  withDisplayName:(nullable NSString*)displayName
                 withLanguageCode:(nullable NSString*)languageCode;

/*! @brief Indicates whether the player should continue the playback in the background. The default value is NO.
 @discussion Besides setting this flas to 'true' please add the UIBackgroundModes key in your app's Info.plist file. Its value is an array that contains one or more strings that identify which background tasks your application supports. Specify the string value "audio"
 @remark Works only for audio-only streams
 @remark Must be called before [open] */
@property (nonatomic) BOOL continuePlaybackInTheBackground;


/*!
 @brief Pause playback when an audio device (either wired or wireless) is disconnected
 
 @remark Default value is NO.
 */
@property bool pausePlaybackWhenHeadphonesAreDisconnected;

/*!
 @discussion Optional configuration for Chromecast
 @param url Stream url
 @param configuration DRM configuration
 @param contentType Stream content type
 @param subtitles CustomSubtitles helper class can be used to create proper list of subtitles. Array of NSString subtitles definitions; this parameter overrides side loaded subtitles from the player. Default value is nil - all player's side-loaded subtitles will be used, if set will override side-loaded subtitles for Chromecast only. Each array elements contains NSDictionary with keys (and NSString values): url, displayName, format, languageCode (track's RFC 1766 language code).
 @param languageCode Preferred subtitle language code to start when casting
 */
-(void) setManifestUrlForChromecast:(NSString*) url
                andDrmConfiguration:(nullable CLDrmConfiguration*) configuration
                andContentType:(CLContentType) contentType
                andCustomSubtitles:(nullable CustomSubtitles *)subtitles
                andPreferredSubtitleLanguage:(nullable NSString*) languageCode;

/*!
 @brief Set max supported resolution.
 @discussion
 DASH: works for both VOD and Live
 HLS: starting with iOS 11.0 it's possible to set the max resolution to be played
 but it only applies to HTTP Live Streaming
 @param width max width supported
 @param height max height supported
 @remark Must be called before [open]
 */
-(void) setMaxResolutionWithWidth: (int) width andHeight:(int) height;

@property (nullable, weak, nonatomic) IBOutlet UIView *bottomControls;
@property (nullable, weak, nonatomic) IBOutlet UIView *topControls;
@property (nullable, weak, nonatomic) IBOutlet UIButton *playBtn;
@property (nullable, weak, nonatomic) IBOutlet UIButton *closeBtn;
@property (nullable, weak, nonatomic) IBOutlet UILabel *currentTimeLabel;
@property (nullable, weak, nonatomic) IBOutlet UILabel *totalTimeLabel;
@property (nullable, weak, nonatomic) IBOutlet UISlider *timeSeekbar;
@property (nullable, weak, nonatomic) IBOutlet UILabel *bottomRightTextArea;
@property (nullable, weak, nonatomic) IBOutlet UILabel *upperLeftTextArea;
@property (nullable, weak, nonatomic) IBOutlet UIImageView *logo;
@property (nullable, weak, nonatomic) IBOutlet UILabel *activityLabel;
@property (nullable, weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nullable, weak, nonatomic) IBOutlet NSLayoutConstraint *bottomControllsConstraint;
@property (nullable, weak, nonatomic) IBOutlet NSLayoutConstraint *topControllsConstraint;
@property (nullable, weak, nonatomic) IBOutlet NSLayoutConstraint *logoConstraint;
@property (nullable, weak, nonatomic) IBOutlet NSLayoutConstraint *bottomTextConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *currentTimeLeadingConst;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *totalTimeTrailingConst;
@property (nullable, weak, nonatomic) IBOutlet UIButton *shareBtn;
@property (nullable, weak, nonatomic) IBOutlet UIButton *pipButton;
@property (nullable, weak, nonatomic) IBOutlet UIView *airPlayView;
@property (nullable, weak, nonatomic) IBOutlet UIView *chromecastButtonParent;
@property (nullable, weak, nonatomic) IBOutlet UIView *chromecastMinicontrollerParent;
@property (nullable, weak, nonatomic) IBOutlet UILabel *playbackRateLabel;


@property (nullable, nonatomic) CLSubtitlesStyle* subtitleStyle;

- (IBAction)onPlayButton:(id)sender;
- (IBAction)onCloseButton:(id)sender;
- (IBAction)onTracksButton:(id)sender;
- (IBAction)onSeekBarTouchUp:(id)sender;
- (IBAction)onSeekBarValueChanged:(id)sender;
- (IBAction)onForwardButton:(id)sender;
- (IBAction)onRewindButton:(id)sender;
- (IBAction)onRestartButton:(id)sender;
- (IBAction)onShareButton:(id)sender;
- (void)closeController;
- (IBAction)onPiPButton:(id)sender;
- (IBAction)onFastForward:(id)sender;
- (IBAction)onSlowForward:(id)sender;

@property (nullable, nonatomic, weak) id<CLPlayerViewControllerDelegate> delegate;

/*! @brief Metadata for the current item. This information are used by different plugins (analytics, chromecast)
 @remark Must be called before [open]
 */
@property (nullable) CLContentMetadata* metadata;

- (void)showWarningAlertWhilePlayerLoads;
- (CGRect)calculateTrackTableSizeForItemsCount:(NSUInteger) count;

- (void)setThumbnailDelegate:(id<CLThumbsDelegate>)thumbsDelegate;
- (void)setThumbnailWithGridResource:(CLGridThumbnail*) gridThumb;
- (void)setThumbnailWithBifFile:(NSString*)bifFilepath;
- (void)setThumbnailWithWebVTTFile:(NSString*)vttFilepath;

- (void) addCustomSubView:(UIView*) view;
- (void) hideControllers;

@property ChaseLiveEdge chaseLiveEdge;
@property Float64 chaseLiveEdgeCatchupThreshold;
@property Float64 chaseLiveEdgeCutoffThreshold;
@property Float64 liveEdgeDelay;
@property Float64 minRebuffer;
@property Float64 minPrebuffer;
@property Float64 maxPrebuffer;
@property Float64 chaseLiveEdgeSpeedupRatio;
@property bool protectedWithoutDRM;
@property Float64 playbackRate;

@end

NS_ASSUME_NONNULL_END

#endif
