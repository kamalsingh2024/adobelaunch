//
//  ViewController.m
//  DRMPlaybackDemo
//
//  Created by Chao Ruan on 20/01/2016.
//  Copyright © 2016 Movideo. All rights reserved.
//

#import "ViewController.h"
#import <CastlabsTVSDK/CastlabsTVSDK.h>

NSString* url = @"https://demo.cf.castlabs.com/media/fps/prog_index.m3u8";

@implementation ViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[CastlabsSDK with:@[]
		andLicenseKey:@""
		  andDelegate:nil
	 ];
}

+ (NSString *)applicationDocumentsDirectory {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}

- (void)viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	
	
	NSBundle* b = [NSBundle bundleWithIdentifier:@"castlabs.CastlabsTVSDK"];
	UIStoryboard* sb = [UIStoryboard storyboardWithName:@"CLAppleTVPlayer"
												 bundle:b];
	CLAppleTVPlayerViewController* vc = [sb instantiateViewControllerWithIdentifier:@"CLAppleTVPlayerViewController"];
	vc.streamUrl = url;

	CLDrmConfiguration* drmConfig = [CLDrmConfiguration new];
	drmConfig.assetId = @"...";
	drmConfig.merchantId = @"...";
	drmConfig.sessionId = @"...";
	drmConfig.userId = @"...";
	drmConfig.environment = kProduction;
	vc.drmConfiguration = drmConfig;
	[self presentViewController:vc animated:NO completion:nil];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

@end
