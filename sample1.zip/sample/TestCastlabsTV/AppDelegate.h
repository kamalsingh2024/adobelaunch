//
//  AppDelegate.h
//  TestCastlabsTV
//
//  Created by Guido Parente on 03/03/2016.
//  Copyright © 2016 castlabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

