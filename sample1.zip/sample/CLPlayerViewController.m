 //
//  CLPlayerViewController.m
//  CastlabsSDK
//
//  Created by Guido Parente on 23/11/2015.
//  Copyright © 2015 castLabs. All rights reserved.
//

#import "CLPlayerViewController.h"
#import "CLWeakInstance.h"

#import <CastlabsSDK/UIAlertController+Multi.h>
#import <CastlabsSDK/CLChromecast.h>
#import <CastlabsSDK/CustomSubtitles.h>
#import <CastlabsSDK/CLLog.h>

static NSString *const AUDIO_TRACKS = @"A_AUDIO_TRACKS";
static NSString *const SUBS_TRACKS = @"B_SUBS_TRACKS";
static NSString *const VIDEO_QUALITIES = @"C_VIDEO_QUALITIES";
static bool const LOG_STATES = false;
static int const TRACK_MENU_ENTRY_DISABLE_KEY = -100;
static int const TRACK_MENU_ENTRY_FORCED_SUBTITLES_KEY = -101;

@interface CLPlayerViewController() <CLPlayerListenerProtocol, CLAdsListener> {
	CALayer* playerLayer;
	UITableView* trackTableView;
    
	NSMutableDictionary* trackInformation;
    CLPlayerVideoTrack* videoTrackDescription;
	UIColor* controlsBackgroundColor;
	CMTime seekableRangeStart;
	CMTime seekableRangeDuration;
	CMTime seekedInLiveStream;
	BOOL playOnReady;
    NSTimer* rangeTimer;
    NSTimer* labelTimer;
    
    CGFloat topConstraintsConstant;
    CGFloat bottomConstraintsConstant;
    CGFloat logoConstraintConstant;
    CGFloat bottomTextConstraintConstant;
    
    CLGridThumbnail *gridThumbnails;
    NSString* bifFilepath;
    NSString* webVTTFilepath;
    id<CLThumbsDelegate> thumbsDelegate;
    
    AVPictureInPictureController* pipController;
    bool isPlaybackEnded;
    
    NSMutableArray *subTracks;
    
    NSString* manifestUrlForChromecast;
    CLDrmConfiguration* drmConfigForChromecast;
    CLContentType contentTypeForChromecast;
    CustomSubtitles *subtitlesForChromecast;
    NSString* preferrredSubLangForChromecast;
    
    int maxResolutionWidth;
    int maxResolutionHeight;
}

@property(nullable, nonatomic, readwrite) id<CLPlayer> player;

@property (strong, nonatomic) CLChromecast *chromecast;
@property (strong, nonatomic) NSMutableArray *customViews;
@property (strong, nonatomic) UIView *playerLayerOverlayView;
@property (strong, nonatomic) NSMutableArray *sideloadSubtitleTracks;
@property (strong, nonatomic) CLAdSession *adsSession;
@property (strong, nonatomic) NSString *errorMessage;

@property (nonatomic) CMTime seekTarget;

@property (nonatomic) BOOL isLive;
@property (nonatomic) BOOL isAdsPlaying;
@property (nonatomic) BOOL isAdsStarted;
@property (nonatomic) BOOL firstPlay;
@property (nonatomic) BOOL controllsVisible;

@property (strong, nonatomic) UIImageView *thumbnailImageView;
@property (nonatomic) BOOL isRequestedThumbnailToHide;

@end

@interface CLPlayerViewController (AudioTrackSelection) <UITableViewDelegate, UITableViewDataSource, AVPictureInPictureControllerDelegate, CLChromecastDelegate> {
	
}
@end

@implementation CLPlayerViewController

NSInteger ERROR_DIALOG = 100;
NSInteger WARNING_DIALOG = 101;

- (id)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        self.preferNativePlayer = true;
        self.showAirplayButton = true;
        self.turnOffAirplayOnClose = true;
        self.continuePlaybackInTheBackground = false;
        self.protectedWithoutDRM = false;
        self.subtitleMode = kSubtitleDisplayModeOnlyForced;
        self.hideLogoAndDebugInfo = false;
        self.preferAutoHideHomeIndicator = true;
        self.disablePictureInPicture = false;
        self.playbackRate = 1.0;
    }
    return self;
}

-(void)displayAlertWithTitle:(NSString*)title message:(NSString*)message andType:(NSInteger)type {
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:title
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    weakify(self);
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              strongify(self);
                                                              if (type == ERROR_DIALOG) {
                                                                  [self.player stop];
                                                                  [self dismissViewControllerAnimated:YES completion:nil];
                                                              }
                                                          }];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void) viewDidLoad {
    [super viewDidLoad];
    
    // Airplay
    if (self.showAirplayButton) {
        [CLPlayerUtils addAirplayButton:_airPlayView];
    }

    weakify(self);
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillTerminateNotification object:[UIApplication sharedApplication] queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        strongify(self);
        if (self.turnOffAirplayOnClose) {
            [CLPlayerUtils airplayActive:NO];
        }
    }];

    // Chromecast
    _chromecast = [CLChromecast createChromecast];

    // pinch to zoom player layer
    [self.view addGestureRecognizer:[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinchGesture:)]];
    [self setupNowPlaying];
    [self setupRemoteTransportControls];
}

-(BOOL)prefersHomeIndicatorAutoHidden {
    return self.preferAutoHideHomeIndicator;
}

-(void) setupNowPlaying {
    NSString* mediaTitle = self.streamUrl;
    if (self.metadata != nil && self.metadata.title != nil) {
        mediaTitle = self.metadata.title;
    }
    NSDictionary* nowPlayingInfo = @{MPMediaItemPropertyTitle : mediaTitle};
    MPNowPlayingInfoCenter.defaultCenter.nowPlayingInfo = nowPlayingInfo;
}

-(void) setupRemoteTransportControls {
    [MPRemoteCommandCenter.sharedCommandCenter.playCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent * _Nonnull event) {
        if (!self.player.isPlaying && !self.player.isEnded) {
            [self.player play];
            return MPRemoteCommandHandlerStatusSuccess;
        }
        return MPRemoteCommandHandlerStatusCommandFailed;
    }];
    
    [MPRemoteCommandCenter.sharedCommandCenter.pauseCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent * _Nonnull event) {
        if (self.player.isPlaying) {
            [self.player pause];
            return MPRemoteCommandHandlerStatusSuccess;
        }
        return MPRemoteCommandHandlerStatusCommandFailed;
    }];
}


- (void)handlePinchGesture:(UIPinchGestureRecognizer *)pinchGesture {
    if (self.player == nil) {
        return;
    }

    if (UIGestureRecognizerStateBegan == pinchGesture.state || UIGestureRecognizerStateChanged == pinchGesture.state) {
        if (pinchGesture.scale > 1.0f) {
            [self.player setVideoGravity:AVLayerVideoGravityResizeAspectFill];
        } else {
            [self.player setVideoGravity:AVLayerVideoGravityResizeAspect];
        }
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	[self uiCosmetics];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceOrientationDidChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];

    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (!self.player) {
        self.firstPlay = true;
        isPlaybackEnded = false;
        self.isAdsPlaying = false;
        self.isAdsStarted = false;
        
        [self loadPlayer];
        if ([self.delegate respondsToSelector:@selector(onViewDidAppear)]) {
            [self.delegate onViewDidAppear];
        }
        
        if (self.chromecast) {
            [self.chromecast setAdsServer:self.adsServerForChromecast];
            [self.chromecast connectWithPlayer:self.player andDelegate:self];
            if ([self.chromecast isCastingActive]) {
                [self showChromecastAlert];
                return;
            }
        }
        if (maxResolutionWidth > 0 || maxResolutionHeight > 0) {
            [self.player setMaxResolutionWithWidth:maxResolutionWidth andHeight:maxResolutionHeight];
        }
        [self setLowLatencyParams];
        self.player.protectedWithoutDRM = self.protectedWithoutDRM;
        [self.player open];  // Player will change its state to STATE_READY when ready to play
    }
}

-(void) setLowLatencyParams {
    if (self.liveEdgeDelay > 0) {
        self.player.liveEdgeDelay = self.liveEdgeDelay;
    }
    if (self.chaseLiveEdgeCatchupThreshold > 0) {
        self.player.chaseLiveEdgeCatchupThreshold = self.chaseLiveEdgeCatchupThreshold;
    }
    if (self.chaseLiveEdgeCutoffThreshold > 0) {
        self.player.chaseLiveEdgeCutoffThreshold = self.chaseLiveEdgeCutoffThreshold;
    }
    if (self.minRebuffer > 0) {
        self.player.minRebufferTime = self.minRebuffer;
    }
    if (self.minPrebuffer > 0) {
        self.player.minPrebufferTime = self.minPrebuffer;
    }
    if (self.maxPrebuffer > 0) {
        self.player.maxPrebufferTime = self.maxPrebuffer;
    }
    if (self.chaseLiveEdgeSpeedupRatio > 0) {
        self.player.chaseLiveEdgeSpeedupRatio = self.chaseLiveEdgeSpeedupRatio;
    }
    self.player.chaseLiveEdge = self.chaseLiveEdge;
}

-(void) showChromecastAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Chromecast Playback"
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleAlert];
    weakify(self)
    [alert addActions:@[
        [SimpleAction initWith:@"Play this item now" handler:^(){
            strongify(self)
            [self.chromecast playItemRemotely];
        }],
        [SimpleAction initWith:@"Cancel" handler:^(){
            strongify(self)
            [self.chromecast attachToExistingSession];
            [alert dismissViewControllerAnimated:true completion:nil];
        }]]
    ];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:nil];
}

-(void) uiCosmetics {
	controlsBackgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.65];
    topConstraintsConstant = _topControllsConstraint.constant;
    bottomConstraintsConstant = _bottomControllsConstraint.constant;
    logoConstraintConstant = _logoConstraint.constant;
    bottomTextConstraintConstant = _bottomTextConstraint.constant;
    
    // move the logo up and the bottom text down
    _logoConstraint.constant =  -120;
    _bottomTextConstraint.constant = -150;
    [self.logo setHidden:true];
    [self.bottomRightTextArea setHidden:true];
    [self.upperLeftTextArea setHidden:true];
    [self.view layoutIfNeeded];
    self.controllsVisible = true;
    self.upperLeftTextArea.text = self.debugText;
	
    self.timeSeekbar.value = 0;
    
    // Hide share button if no delegates are able to handle it
    if (![self.delegate respondsToSelector:@selector(onShareButton:)]) {
        self.shareBtn.hidden = true;
    }
    
    // Logo is hidden if no image is set
    [self.logo setImage:self.logoImage];
    
    // Hide PiP button if not supported
    if (![AVPictureInPictureController isPictureInPictureSupported] || ![CLPlayerUtils isHLS:self.streamUrl] || self.disablePictureInPicture) {
        [self.pipButton setHidden:true];
    } else {
        UIImage* pipImageBtn = [AVPictureInPictureController pictureInPictureButtonStartImageCompatibleWithTraitCollection:nil];
        pipImageBtn = [pipImageBtn imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        [self.pipButton setEnabled:true];
        [self.pipButton setBackgroundImage:pipImageBtn forState:UIControlStateNormal];
        self.pipButton.tintColor = [UIColor whiteColor];
        if (self.showAirplayButton) {
            self.airPlayView.frame = CGRectMake(self.pipButton.frame.origin.x - self.airPlayView.frame.size.width - 10, self.airPlayView.frame.origin.y, self.airPlayView.frame.size.width, self.airPlayView.frame.size.height);
        }
    }
    [self deviceOrientationDidChange:nil];
}

-(void) loadPlayer {
	if (!_streamUrl) {
        os_log(CLLog(OS_LOG_TYPE_ERROR), "No URL specified");
		return;
	}

	playOnReady = YES;
	CLPlayerFactory* factory = [[CLPlayerFactory alloc] init];
    factory.preferNativePlayer = self.preferNativePlayer;
    NSString* jsonDrm = [self getJsonFilePathWithDrmConfigurationForLocalManifest];
    if (jsonDrm) {
        _drmConfiguration = [self parseDrmConfigurationFromJson:jsonDrm];
    }
	
    self.player = [factory createPlayerWithStreamUrl:_streamUrl
                                 andDrmConfiguration:_drmConfiguration
                                  andContentMetadata:self.metadata
                                      andContentType:_contentType];
	
	if (!self.player) {
		dispatch_async(dispatch_get_main_queue(), ^{ // UI changes need to be done on main thread
            [self displayAlertWithTitle:@"SDK Error" message:@"ERROR - There was an error instating the player" andType:ERROR_DIALOG];
		});
		return;
	}

	self.player.subtitleStyle = self.subtitleStyle;
    self.player.continuePlaybackInTheBackground = self.continuePlaybackInTheBackground;
    self.player.pausePlaybackWhenHeadphonesAreDisconnected = self.pausePlaybackWhenHeadphonesAreDisconnected;
    cl_log("Playback loop enabled %d" , self.loopEnabled);
    //NSDictionary* dict = @{@"headerKey":@"headerValue"};
    //[player setCustomHTTPHeaders:dict];
    [self.player addListener:self];
    self.player.analyticsDelegate = self.analyticsDelegate;
    self.player.disablePictureInPicture = self.disablePictureInPicture;
    
    if (self.startPosition != 0 && self.firstPlay) {
        CMTime seekToSeconds = CMTimeMake(self.startPosition, 1000);
        self.player.startPosition = seekToSeconds;
    }

    if (gridThumbnails) {
        [self.player setThumbnailWithGridResource:gridThumbnails];
    } else if (bifFilepath) {
        [self.player setThumbnailWithBifFile:bifFilepath];
    } else if (webVTTFilepath) {
        [self.player setThumbnailWithWebVTTtrack:webVTTFilepath];
    } else if (thumbsDelegate) {
        [self.player setThumbnailDelegate:thumbsDelegate];
    }

    if (self.fairplayScheme) {
        self.player.fairplayScheme = self.fairplayScheme;
    }

    if (self.turnOffAirplayOnClose) {
        [CLPlayerUtils airplayActive:YES];
    }

    // NOTE: if the authToken is rotate every request we should get
    //       a separate token for Chromecast
    if (self.drmConfiguration.authToken != nil && ![self.drmConfiguration.authToken isEqualToString:@""] && self.assetConfigurationUrl != nil && ![self.assetConfigurationUrl isEqualToString:@""]) {

        [self requestAuthTokenForChromecast];
    }

    if (manifestUrlForChromecast || drmConfigForChromecast) {
        cl_log("Setting alternate configuration for chromecast");
        [self setManifestUrlForChromecast:manifestUrlForChromecast
                      andDrmConfiguration:drmConfigForChromecast
                           andContentType:contentTypeForChromecast
                       andCustomSubtitles:subtitlesForChromecast
             andPreferredSubtitleLanguage:preferrredSubLangForChromecast];
    }
}

-(void)requestAuthTokenForChromecast {
    manifestUrlForChromecast = self.streamUrl;
    contentTypeForChromecast = self.contentType;
    drmConfigForChromecast = [self.drmConfiguration copyWithZone:nil];

    // NOTE: code duplication, this is example code
    NSMutableURLRequest *requestAssetConfiguration = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:self.assetConfigurationUrl]];
    NSString *apiToken = [[NSUserDefaults standardUserDefaults] stringForKey:@"cmsToken"];
    [requestAssetConfiguration setValue:[NSString stringWithFormat:@"Token %@", apiToken]
                     forHTTPHeaderField:@"Authorization"];

    dispatch_semaphore_t sem;
    __block NSData *result = nil;
    sem = dispatch_semaphore_create(0);
    [[[NSURLSession sharedSession] dataTaskWithRequest:requestAssetConfiguration completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {

        if (error == nil) {
            result = data;
        }
        dispatch_semaphore_signal(sem);
    }] resume];
    dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);

    NSDictionary *config = [NSJSONSerialization JSONObjectWithData:result options:0 error:nil];
    if (config != nil) {
        NSDictionary *drm = config[@"drmConfiguration"];
        drmConfigForChromecast.authToken = drm[@"authToken"];
    }
}

/// Returns nil if nothing is found
-(NSString*) getJsonFilePathWithDrmConfigurationForLocalManifest {
	NSString* jsonDrm;
	NSRange lastComma = [_streamUrl rangeOfString:@"Manifest.mpd" options:NSBackwardsSearch];
	
	if(lastComma.location != NSNotFound) {
		jsonDrm = [_streamUrl stringByReplacingCharactersInRange:lastComma
																withString: @"drm.json"];
		jsonDrm =  [jsonDrm stringByReplacingOccurrencesOfString:@"file://" withString:@""];
		if ([[NSFileManager defaultManager] fileExistsAtPath:jsonDrm]) {
			return jsonDrm;
		}
	}
	return nil;
}

-(CLDrmConfiguration*) parseDrmConfigurationFromJson:(NSString*) jsonPath {
    CLDrmConfiguration* drm =[[CLDrmConfiguration alloc] init];
    drm.workingDirectory = [CLPlayerUtils drmWorkingDirectory];
    drm.tempDirectory = [CLPlayerUtils applicationTmpDirectory];
	NSData *content = [[NSData alloc] initWithContentsOfFile:jsonPath];
	NSDictionary *json = [NSJSONSerialization JSONObjectWithData:content options:kNilOptions error:nil];
	drm.assetId = [json valueForKey:@"asset"];
	drm.merchantId = [json valueForKey:@"merchant"];
	drm.userId = [json valueForKey:@"user"];
	NSString* env = [json valueForKey:@"env"];
	if ([env isEqualToString:@"testing"]) {
		drm.environment = kTesting;
	} else if ([env isEqualToString:@"staging"]) {
		drm.environment = kStaging;
	} if ([env isEqualToString:@"production"]) {
		drm.environment = kProduction;
	}
	drm.sessionId = [json valueForKey:@"session"];
	return drm;
}

-(void) onPlayerReady {
    weakify(self);
	dispatch_async(dispatch_get_main_queue(), ^{ // UI changes need to be done on main thread
        strongify(self);
        [self addPlayerViewToController];
        [self addTapListenerToPlayerView];
        for (UIView* view in self.customViews) {
            [self.view insertSubview:view belowSubview:self.playerLayerOverlayView];
        }
        for (NSMutableDictionary *subtitleTrackInfo in self.sideloadSubtitleTracks) {
            [self.player addSubtitlesTrackFromUrl:subtitleTrackInfo[@"url"] withFormat:[subtitleTrackInfo[@"format"] intValue] withDisplayName:subtitleTrackInfo[@"displayName"] withLanguageCode:subtitleTrackInfo[@"languageCode"]];
        }

        [self loadTracksInfo];
		CMTime duration = [self.player duration];
		if (CMTIME_IS_INDEFINITE(duration)) {
			self.isLive = true;
			[self updateSeekingRanges];
		}

		if (!self.isLive) {
            if (duration.timescale != 0) {
                self.totalTimeLabel.text = [CLPlayerUtils cmTimeToString:duration];
                self.timeSeekbar.maximumValue = CMTimeGetSeconds(duration);
            } else {
                // Disable seekbar
                self.timeSeekbar.enabled = NO;
                self.timeSeekbar.maximumValue = 0;
                self.timeSeekbar.value = 0;
            }
		} else { // Live Stream
			self.totalTimeLabel.text = @"LIVE";
		}
        [self setupTimers];
        if (self.adsServer && !self.adsSession) {
            [self startAdSession];
        } else {
            if (!self.isAdsPlaying) {
                if (!self.disablePictureInPicture) {
                    [self initPictureInPicture];
                }
                bool wasFirstPlay = self.firstPlay;
                [self play];
                if (wasFirstPlay) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        strongify(self)
                        [self automaticSubtitleSelection];
                    });
                }
            }
        }

        cl_log("Playback Type: %@", [self.player getPlaybackType]);
	});
}

-(void) play {
    if (playOnReady) {
        [self.player play];
        self.firstPlay = false;
        [self updatePlaybackRate];
    }
}

- (void) startAdSession {
    self.adsSession = [CLAdSession createAdSession];
    if (self.adsSession != nil) {
        [self.player addAdListener:self];
        self.adsSession = [self.adsSession initWithPlayer:self.player forViewController:self onView:self.view];
        cl_log("requestAd @ %@", self.adsServer);
        [self.adsSession requestAds:self.adsServer];
    }
}

- (void) stopAdSession {
    if (self.adsSession) {
        [self.adsSession destroy];
        self.adsSession = nil;
        self.isAdsPlaying = false;
    }
}

#pragma mark - CLAdsListener

-(void)adStopped:(CLAdEvent *)event {
    // Not implemented
}

-(void)adStarted:(CLAdEvent *)event {
    // Not implemented
    self.isAdsStarted = true;
}

-(void)adEvent:(CLAdEvent *)event {
    if (event.type == kAdEvent_ALL_ADS_COMPLETED) {
        self.isAdsStarted = false;
    }
}

- (void)adsLoaded:(NSDictionary*) adsInfo {
    bool isPreroolAdPresent = false;
    NSArray* adCuepoints = [adsInfo objectForKey:@"adCuePoints"];
    for (NSNumber* adCuepoint in adCuepoints) {
        if (adCuepoint.integerValue == 0) {
            isPreroolAdPresent = true;
        }
    }
    if (!isPreroolAdPresent) {
        [self play];
    }
}

- (void)didRequestContentPause {
    self.isAdsPlaying = true;
    [self.player pause];
}

- (void)didRequestContentResume {
    self.isAdsPlaying = false;
    if (isPlaybackEnded) {
        [self.player stopAnalyticsSession];
    } else {
        if ([self.chromecast isCastingActive]) {

        } else {
            [self.player play];
        }
    }
}

-(void) addPlayerViewToController {
	playerLayer = self.player.playerView;
	[self centerPlayerView];
	playerLayer.backgroundColor = [[UIColor blackColor] CGColor];

    if (playerLayer.superlayer == nil) {
        // NOTE: do not insert same layer multiple times
        [self.view.layer insertSublayer:playerLayer below:self.topControls.layer];
    }
}

-(void) centerPlayerView {
    CGRect fullScreenRect = self.view.bounds;
	playerLayer.frame = fullScreenRect;
	playerLayer.position = CGPointMake(CGRectGetMidX(fullScreenRect), CGRectGetMidY(fullScreenRect));
}

- (void)viewWillTransitionToSize:(CGSize)size
       withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    if ([self.delegate respondsToSelector:@selector(onViewWillTransitionToSize:)]) {
        [self.delegate onViewWillTransitionToSize:size];
    }
}

-(void) deviceOrientationDidChange:(NSNotification *)notification {
    CGSize screenSize = [[UIScreen mainScreen] bounds].size;
    // There are cases where at this point the 'UIDevice orientation' is reported correctly but 'UIScreen width/height' are not yet updated. If this is the case we swap the values
    if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation)) {
        if (screenSize.height > screenSize.width) {
            screenSize = CGSizeMake(screenSize.height, screenSize.width);
        }
        _currentTimeLeadingConst.constant = 44;
        _totalTimeTrailingConst.constant = 44;
    } else {
        if (screenSize.width > screenSize.height) {
            screenSize = CGSizeMake(screenSize.height, screenSize.width);
        }
        _currentTimeLeadingConst.constant = 16;
        _totalTimeTrailingConst.constant = 16;
    }
    playerLayer.frame = self.view.bounds;
    if (self.playerLayerOverlayView != nil) {
        self.playerLayerOverlayView.frame = CGRectMake(0, 0, screenSize.width, screenSize.height);
    }
    [trackTableView setHidden:YES];
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}

- (void)setupTimers {
    // Update seeking ranges (if we are live-streaming)
    if (self.isLive && !rangeTimer) {
        rangeTimer = [NSTimer scheduledTimerWithTimeInterval:1.0/1.0
                                                      target:self
                                                    selector:@selector(updateSeekingRanges)
                                                    userInfo:nil
                                                     repeats:YES];
        [rangeTimer fire];
	}
	
    // Update labels
    if (!labelTimer) {
        labelTimer = [NSTimer scheduledTimerWithTimeInterval:1.0/2.0
                                                      target:self
                                                    selector:@selector(updateLabels)
                                                    userInfo:nil
                                                     repeats:YES];
        [labelTimer fire];
    }
}

- (void)invalidateTimers {
    if (rangeTimer) {
        [rangeTimer invalidate];
        rangeTimer = nil;
    }
    if (labelTimer) {
        [labelTimer invalidate];
        labelTimer = nil;
    }
}

- (IBAction)onPlayButton:(id)sender {
	StateID state = self.player.state;
	if (STATE_PLAYING != state && STATE_STALLED != state) {
        if (isPlaybackEnded) {
            [self replay];
        } else {
            [self.player play];
        }
	} else {
		[self.player pause];
	}
}

-(void) replay {
    if (self.adsSession) {
        [self.adsSession destroy];
        self.adsSession = nil;
    }
    [self seek:kCMTimeZero];
}

- (IBAction)onTracksButton:(UIButton*)sender {
	[self toggleTracksView];
}

- (IBAction)onForwardButton:(id)sender {
    CMTime seekStart = [self.player position];
    if (self.player.state == STATE_SEEKING  && CMTIME_IS_VALID(self.seekTarget)) {
        seekStart = self.seekTarget;
        [self updateTimeLabel:seekStart];
    }
	CMTime seekTime = CMTimeAdd(seekStart, CMTimeMakeWithSeconds(10, 1));
    if (self.isLive) {
        seekTime = [self drySeekOnLiveStream: CMTimeAdd(CMTimeMakeWithSeconds(_timeSeekbar.value, 1000), CMTimeMakeWithSeconds(10, 1))];
    }

    if (self.player.state == STATE_PLAYING) {
        [self seek:seekTime];
        [self updateLabels];
    }
}

- (IBAction)onRewindButton:(id)sender {
    CMTime seekStart = [self.player position];
    if (self.player.state == STATE_SEEKING  && CMTIME_IS_VALID(self.seekTarget)) {
        seekStart = self.seekTarget;
        [self updateTimeLabel:seekStart];
    }
    CMTime seekTime = CMTimeAdd(seekStart, CMTimeMakeWithSeconds(-10, 1));
    if (self.isLive) {
        seekTime = [self drySeekOnLiveStream: CMTimeSubtract(CMTimeMakeWithSeconds(_timeSeekbar.value, 1000), CMTimeMakeWithSeconds(10, 1))];
    }

    if (self.player.state == STATE_PLAYING) {
        [self seek:seekTime];
        [self updateLabels];
    }
}

- (IBAction)onRestartButton:(id)sender {
	CMTime seekTime = CMTimeMakeWithSeconds(0, 1);
    if (self.isLive) {
        seekTime = [self drySeekOnLiveStream:seekTime];
    }
    [self seek:seekTime];
}

- (IBAction) onShareButton:(id)sender {
    if ([self.delegate respondsToSelector:@selector(onShareButton:)]) {
        [self.delegate onShareButton:sender];
    }
}

- (void) showWarningAlertWhilePlayerLoads {
    [self displayAlertWithTitle:@"Content not ready" message:@"Player is still loading" andType:WARNING_DIALOG];
}

- (IBAction)onCloseButton:(id)sender {
    if (self.turnOffAirplayOnClose) {
        [CLPlayerUtils airplayActive:NO];
    }

    [self closeController];
}

-(void) closeController {
    [self invalidateTimers];
    [self.player removeListener:self];
    [self stopAdSession];
    [self.player stop];
    [self.player removeListener:self];
    [trackTableView setHidden:YES];
    if ([self.delegate respondsToSelector:@selector(didDismissPlayerViewController:)]) {
        [self.delegate didDismissPlayerViewController:self];
    }
    [self.player stopAnalyticsSession];

    [self dismissViewControllerAnimated:YES completion:nil];
    self.chromecast = nil;
    self.player = nil;
}

- (IBAction) onSeekBarTouchUp:(id)sender {
	CMTime seekTime = CMTimeMakeWithSeconds(_timeSeekbar.value, 1000);
	if (!self.isLive) {
		_timeSeekbar.value = CMTimeGetSeconds(seekTime);
		_currentTimeLabel.text = [CLPlayerUtils cmTimeToString:seekTime];
        self.thumbnailImageView.hidden = true;
        self.isRequestedThumbnailToHide = true;
	} else {
		seekTime = [self drySeekOnLiveStream:seekTime];
	}
	[self seek:seekTime];
}


- (IBAction)onSeekBarValueChanged:(id)sender {
    self.isRequestedThumbnailToHide = false;
	CMTime seekTime = CMTimeMakeWithSeconds(_timeSeekbar.value, 1000);
	_currentTimeLabel.text = [CLPlayerUtils cmTimeToString:seekTime];
	if (!self.isLive) {
		_currentTimeLabel.text = [CLPlayerUtils cmTimeToString:seekTime];
        [self updateCurrentThumbnail:seekTime];
	} else {
		[self drySeekOnLiveStream:seekTime];
	}
}

-(void)onFastForward:(id)sender {
    self.playbackRate += 0.5;
    [self updatePlaybackRate];
}

- (void)onSlowForward:(id)sender {
    if (self.playbackRate - 0.5 > 0) {
        self.playbackRate -= 0.5;
    }
    [self updatePlaybackRate];
}

-(void) updatePlaybackRate {
    self.player.playbackRate = self.playbackRate;
    dispatch_async(dispatch_get_main_queue(), ^{ // UI changes need to be done on main thread
        self.playbackRateLabel.text = [NSString stringWithFormat:@"%.1fx" , self.player.playbackRate];
        if (self.player.playbackRate == 1) {
            weakify(self);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                strongify(self);
                self.playbackRateLabel.hidden = true;
            });
        } else {
            self.playbackRateLabel.hidden = false;
        }
    });
}

- (void) updateTimeLabel:(CMTime)time {
    _timeSeekbar.value = CMTimeGetSeconds(time);
    _currentTimeLabel.text = [CLPlayerUtils cmTimeToString:time];
}

- (void) updateLabels {
	CMTime currentTime = [self.player position];
	if (![_timeSeekbar isTracking] && [self.player state] != STATE_SEEKING) {
		if (!self.isLive) {
            [self updateTimeLabel:currentTime];
		}
	}
	if ([self.player quality]) {
		int bitrate = [[[self.player quality] valueForKey:@"bitrate"] floatValue] / 1000;
		self.bottomRightTextArea.text = [NSString stringWithFormat:@"%@x%@ @ %@ Kbps",
										 [[self.player quality] valueForKey:@"width"],
										 [[self.player quality] valueForKey:@"height"],
										  @(bitrate)];
	}
    if (self.isLive) {
        if (CMTIME_IS_VALID(seekableRangeDuration)) {
            self.timeSeekbar.enabled = YES;
            self.timeSeekbar.maximumValue = CMTimeGetSeconds(seekableRangeDuration);
            if (self.firstPlay) {
                self.timeSeekbar.value = CMTimeGetSeconds(seekableRangeDuration);
            }
            //self.totalTimeLabel.text = CMTimeGetSeconds(seekableRangeDuration);
        } else {
            // Disable seekbar
            self.timeSeekbar.enabled = NO;
            self.timeSeekbar.maximumValue = 0;
            self.timeSeekbar.value = 0;
        }
    }
}

-(void) updateCurrentThumbnail:(CMTime) timestamp {
    if (thumbsDelegate || gridThumbnails || bifFilepath || webVTTFilepath) {
        CLThumb* thumb = [self.player getThumb:timestamp];
        if (thumb) {
            [self drawThumbnailOnSeekbar:thumb];
        }
    }
}

-(void) drawThumbnailOnSeekbar:(CLThumb*) thumb {
    UIImage* image = [UIImage imageWithData:thumb.imageData];
    CGRect trackRect = [self.timeSeekbar trackRectForBounds:self.timeSeekbar.bounds];
    CGRect thumbRect = [self.timeSeekbar thumbRectForBounds:self.timeSeekbar.bounds
                                                  trackRect:trackRect
                                                      value:self.timeSeekbar.value];
    weakify(self)
    dispatch_async(dispatch_get_main_queue(), ^{
        strongify(self)
        if (self.isRequestedThumbnailToHide) {
            return;
        }
        if (!self.thumbnailImageView) {
            self.thumbnailImageView = [[UIImageView alloc] initWithImage:image];
            [self.view addSubview:self.thumbnailImageView];
            [self.view bringSubviewToFront:self.thumbnailImageView];
        } else {
            [self.thumbnailImageView setImage:image];
        }
        self.thumbnailImageView.hidden = false;
        CGPoint abs = [self.timeSeekbar.superview convertPoint:self.timeSeekbar.frame.origin toView:nil];
        self.thumbnailImageView.center = CGPointMake(thumbRect.origin.x + self.timeSeekbar.frame.origin.x,  self.timeSeekbar.frame.origin.y - 20);
        self.thumbnailImageView.frame = CGRectMake(self.thumbnailImageView.frame.origin.x, abs.y - self.thumbnailImageView.frame.size.height, self.thumbnailImageView.frame.size.width, self.thumbnailImageView.frame.size.height);
    });
}

- (void) updateSeekingRanges {
	if ( [self.player respondsToSelector:@selector(seekableTimeRanges)]) {
		NSArray* seekableRanges = self.player.seekableTimeRanges;
		for (id range in seekableRanges) {
			seekableRangeStart = [range CMTimeRangeValue].start;
			seekableRangeDuration = [range CMTimeRangeValue].duration;
			break;
		}
	}
}

-(void) seek: (CMTime) time {
	StateID state = [self.player state];
	playOnReady |= (STATE_PLAYING == state);
    playOnReady &= (STATE_PAUSED != state);
    self.seekTarget = time;
	[self.player seek:time];
}

/// Update labels and sanitize seekTime for live stream
/// without actually seeking
-(CMTime) drySeekOnLiveStream:(CMTime) offsetTime {
    CMTime tolerance = CMTimeMake(1, 5);
    if (CMTimeGetSeconds(offsetTime) <= CMTimeGetSeconds(tolerance)) {
        offsetTime = tolerance;
        _timeSeekbar.value = CMTimeGetSeconds(kCMTimeZero);
        _currentTimeLabel.text = [NSString stringWithFormat:@"-%@", [CLPlayerUtils cmTimeToString:seekableRangeDuration]];
    } else if (CMTimeGetSeconds(offsetTime) >= CMTimeGetSeconds(CMTimeSubtract(seekableRangeDuration, tolerance))) {
        offsetTime = CMTimeSubtract(seekableRangeDuration, tolerance);
        _timeSeekbar.value = CMTimeGetSeconds(seekableRangeDuration);
        _currentTimeLabel.text = [CLPlayerUtils cmTimeToString:kCMTimeZero];
	} else {
        _currentTimeLabel.text = [NSString stringWithFormat:@"-%@", [CLPlayerUtils cmTimeToString:CMTimeSubtract(seekableRangeDuration, offsetTime)]];
        _timeSeekbar.value = CMTimeGetSeconds(offsetTime);
	}
    CMTime absoluteSeekTime = CMTimeAdd(seekableRangeStart, offsetTime);
	return absoluteSeekTime;
}

-(void) addTapListenerToPlayerView{
	UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onPlayerViewTapped:)];
	singleTap.numberOfTapsRequired = 1;
	singleTap.numberOfTouchesRequired = 1;
	// We can't attach a gesture recognizer to a CALayer thus we need an overlay transparent view
	CGRect fullScreenRect = CGRectMake(0,
									   0,
									   [[UIScreen mainScreen] bounds].size.width,
									   [[UIScreen mainScreen] bounds].size.height);
	self.playerLayerOverlayView = [[UIView alloc] initWithFrame:fullScreenRect];
	[self.playerLayerOverlayView addGestureRecognizer:singleTap];
	[self.playerLayerOverlayView setUserInteractionEnabled:YES];
	[self.view insertSubview:self.playerLayerOverlayView belowSubview:_topControls];
}

- (void)onPlayerViewTapped:(UIGestureRecognizer *)gestureRecognizer {
    if (self.autoHideControls) {
        [self toggleControlsVisibility];
    }

    if ([self.delegate respondsToSelector:@selector(onPlayerViewControllerTapped)]) {
        [self.delegate onPlayerViewControllerTapped];
    }
}

- (void) hideControllers {
    double screenHeight= [[UIScreen mainScreen] bounds].size.height;
    [trackTableView setHidden:YES];
    // move the logo out
    self.controllsVisible = false;
    [self.logo setHidden:false];
    [self.bottomRightTextArea setHidden:false];
    [self.upperLeftTextArea setHidden:false];
    _logoConstraint.constant =  logoConstraintConstant;
    _bottomTextConstraint.constant = bottomTextConstraintConstant;
    _bottomControllsConstraint.constant = -screenHeight;
    _topControllsConstraint.constant = -screenHeight;
}

- (void) toggleControlsVisibility {
    bool wasControlVisible = self.controllsVisible;
    double screenHeight= [[UIScreen mainScreen] bounds].size.height;
    if(self.controllsVisible) {
        [self hideControllers];
    } else {
        self.controllsVisible = true;
        _logoConstraint.constant =  -screenHeight;
        _bottomTextConstraint.constant = -screenHeight;
        _bottomControllsConstraint.constant = bottomConstraintsConstant;
        _topControllsConstraint.constant = topConstraintsConstant;
    }

    [self.view setNeedsUpdateConstraints];
    weakify(self);
    [UIView animateWithDuration:0.25 animations:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            strongify(self);
            [self.view layoutIfNeeded];
        });
    } completion:^(BOOL finished){
        strongify(self);
        [self.logo setHidden:self.controllsVisible || self.hideLogoAndDebugInfo];
        [self.bottomRightTextArea setHidden:self.controllsVisible || self.hideLogoAndDebugInfo];
        [self.upperLeftTextArea setHidden:self.controllsVisible || self.hideLogoAndDebugInfo];
    }];
    if ([self.delegate respondsToSelector:@selector(onToggleControlsVisibility:)]) {
        [self.delegate onToggleControlsVisibility:wasControlVisible];
    }
}

-(void) automaticSubtitleSelection {
    if (self.subtitleMode == kSubtitleDisplayModeNone) {
        [self.player selectSubtitleTrack:-1];
        return;
    }
    NSString* defaultTextLanguageCode = [self getDefaultTextLanguageCode];
    NSLocale* preferredLocale = [NSLocale localeWithLocaleIdentifier:defaultTextLanguageCode];
    CLPlayerSubtitleTrack* subtitleTrackWithPreferredLanguage;
    CLPlayerSubtitleTrack* forcedSubtitleTrackWithPreferredLanguage;
    for (int trackIndex=0; trackIndex < subTracks.count; trackIndex++) {
        CLPlayerSubtitleTrack* desc = [subTracks objectAtIndex:trackIndex];
        if (desc.languageCode) {
            NSLocale* locale = [NSLocale localeWithLocaleIdentifier:desc.languageCode];
            if ([preferredLocale.localeIdentifier isEqualToString:locale.localeIdentifier]) {
                if (desc.forced) {
                    forcedSubtitleTrackWithPreferredLanguage = desc;
                } else {
                    subtitleTrackWithPreferredLanguage = desc;
                }
            }
        }
    }
    if (self.subtitleMode == kSubtitleDisplayModeOnlyForced) {
        if (forcedSubtitleTrackWithPreferredLanguage) {
            [self.player selectSubtitleTrack:forcedSubtitleTrackWithPreferredLanguage.trackIndex];
        }
    } else if (self.subtitleMode == kSubtitleDisplayModePreferredLanguage) {
        if (subtitleTrackWithPreferredLanguage) {
            [self.player selectSubtitleTrack:subtitleTrackWithPreferredLanguage.trackIndex];
        } else if (forcedSubtitleTrackWithPreferredLanguage) {
            [self.player selectSubtitleTrack:forcedSubtitleTrackWithPreferredLanguage.trackIndex];
        }
    }
}

-(NSString*) getDefaultTextLanguageCode {
    NSString* languageIdentifier = [[NSLocale preferredLanguages] firstObject];
    NSLocale* preferredLocale = [[NSLocale alloc] initWithLocaleIdentifier: languageIdentifier];
    NSString* languageCode = languageIdentifier;
    if (@available(iOS 10.0, *)) {
        languageCode = [preferredLocale languageCode];
    }
    NSArray* audioTracks = [trackInformation objectForKey:AUDIO_TRACKS];
    if (self.preferredTextLanguage) {
        languageCode = self.preferredTextLanguage;
    } else {
        CLPlayerAudioTrack* currentAudioTrack = [audioTracks objectAtIndex:[self.player currentAudioTrackIndex]];
        if (currentAudioTrack && currentAudioTrack.languageCode) {
            languageCode = currentAudioTrack.languageCode;
        }
    }
    return languageCode;
}

- (void)beginActivity:(NSString*)label {
    weakify(self);
    dispatch_async(dispatch_get_main_queue(), ^{\
        strongify(self);
        self.activityLabel.text = label;
        self.activityLabel.hidden = NO;
        [self.activityIndicator startAnimating];
    });
}

- (void)endActivity {
    weakify(self);
    dispatch_async(dispatch_get_main_queue(), ^{
        strongify(self);
        self.activityLabel.hidden = YES;
        [self.activityIndicator stopAnimating];
    });
}

-(void) onStateFinished {
	cl_log("Playback ended");
	if (self.loopEnabled && self.errorMessage == nil) {
        cl_log("Loop is enabled - Restarting playback");
        [self replay];
    } else if (!self.isAdsStarted) {
        isPlaybackEnded = true;
    }
}

- (void) initPictureInPicture {
    pipController = [self.player getPictureInPictureController];
    pipController.delegate = self;
}

- (void)onPiPButton:(id)sender {
    if (pipController) {
        if ([pipController isPictureInPictureActive]) {
            cl_log("Stopping PiP");
            [pipController stopPictureInPicture];
        } else {
            cl_log("Starting PiP");
            [pipController startPictureInPicture];
        }
    }
}

- (void)addSubtitlesTrackFromUrl:(NSURL *)url
                      withFormat:(CLSubtitleFormat) format
                 withDisplayName:(NSString *)displayName
                  withLanguageCode:(NSString* _Nullable) languageCode {
    if (self.sideloadSubtitleTracks == nil) {
        self.sideloadSubtitleTracks = [NSMutableArray array];
    }

    NSMutableDictionary *trackInfo = [NSMutableDictionary dictionary];
    trackInfo[@"url"] = url;
    trackInfo[@"displayName"] = displayName;
    trackInfo[@"languageCode"] = languageCode;
    trackInfo[@"format"] = [NSNumber numberWithInteger:format];
    [self.sideloadSubtitleTracks addObject: trackInfo];
}

- (void)setSubtitleStyle:(CLSubtitlesStyle *)subtitleStyle {
    _subtitleStyle = subtitleStyle;
    self.player.subtitleStyle = _subtitleStyle;
}

- (void)setManifestUrlForChromecast:(NSString *)url andDrmConfiguration:(CLDrmConfiguration *)configuration andContentType:(CLContentType)contentType andCustomSubtitles:(CustomSubtitles *)subtitles andPreferredSubtitleLanguage:(nullable NSString *)languageCode{
    manifestUrlForChromecast = url;
    drmConfigForChromecast = configuration;
    contentTypeForChromecast = contentType;
    subtitlesForChromecast = subtitles;
    preferrredSubLangForChromecast = languageCode;
    
    [self.player setManifestUrlForChromecast:url andDrmConfiguration:configuration andContentType:contentType andCustomSubtitles:[subtitles list] andPreferredSubtitleLanguage:preferrredSubLangForChromecast];
}

- (void)addCustomSubView:(UIView *)view {
    if (self.customViews == nil) {
        self.customViews = [NSMutableArray array];
    }
    [self.customViews addObject:view];
}

- (void)setMaxResolutionWithWidth:(int)width andHeight:(int)height {
    maxResolutionWidth = width;
    maxResolutionHeight = height;
}

#pragma CLPlayerListenerProtocol

- (void) onStateChangedTo:(StateID)state from:(StateID)oldState withData:(NSDictionary*)data{
    //cl_log("Youbora State Old/New: %@ / %@", [CLPlayerUtils playerStatusToString:oldState], [CLPlayerUtils playerStatusToString:state]);
    weakify(self);
    dispatch_async(dispatch_get_main_queue(), ^{
        strongify(self);
        self.timeSeekbar.enabled = state != STATE_LOADING;
        switch (state) {
            case STATE_LOADING:
                if (LOG_STATES) cl_log("STATE_LOADING");
                [self beginActivity:@"LOADING"];
                break;
            case STATE_PLAYING:
                if (LOG_STATES) cl_log("STATE_PLAYING");
                self.seekTarget = kCMTimeInvalid;
                [self endActivity];
                [[self playBtn] setSelected:true];
                break;
            case STATE_PAUSED:
                if (LOG_STATES) cl_log("STATE_PAUSED");
                [self endActivity];
                [[self playBtn] setSelected:false];
                break;
            case STATE_SEEKING:
                if (LOG_STATES) cl_log("STATE_SEEKING");
                [self beginActivity:@"SEEKING"];
                break;
            case STATE_FINISHED:
                if (LOG_STATES) cl_log("STATE_FINISHED");
                [self endActivity];
                [[self playBtn] setSelected:false];
                [self onStateFinished];
                break;
            case STATE_READY:
                if (LOG_STATES) cl_log("STATE_READY");
                [self endActivity];
                [self onPlayerReady];
                break;
            case STATE_STALLED:
                if (LOG_STATES) cl_log("STATE_STALLED");
                [self beginActivity:@"BUFFERING"];
                break;
            case STATE_UNKNOWN:
                // fall-trough
            default:
                break;
        }
    });
}

- (void) onEvent:(EventID)eventID {
    if (eventID == EVENT_AIRPLAY_START && self.playbackRate > 2.0) {
        self.playbackRate = 1.0;
        [self updatePlaybackRate];
    }
}

- (void) onError:(ErrorID) errorID withMessage:(NSString*) errorDetail {
	self.errorMessage =[CLPlayerUtils playerErrorToString:errorID];
	if (errorDetail) {
		self.errorMessage = [NSString stringWithFormat:@"%@. %@", self.errorMessage, errorDetail];
	}
	cl_log_error("%@", self.errorMessage);
	dispatch_async(dispatch_get_main_queue(), ^{ // UI changes need to be done on main thread

        [self displayAlertWithTitle:@"SDK Error" message:self.errorMessage andType:ERROR_DIALOG];

        if (self.player) {
            [self.player stop];
        }
	});
}

- (NSString *)onAuthTokenRequired {
    if (self.delegate && [self.delegate respondsToSelector:@selector(onAuthTokenRequired)]) {
        return [self.delegate onAuthTokenRequired];
    }
    return nil;
}

- (void)onPlaybackInfo:(CLPlaybackInfo *)info {
    if (self.delegate && [self.delegate respondsToSelector:@selector(onPlaybackInfo:)]) {
        return [self.delegate onPlaybackInfo:info];
    }
}

- (NSData *)getCKC:(NSData *)keyServerResponse {
    if (self.delegate && [self.delegate respondsToSelector:@selector(getCKC:)]) {
        return [self.delegate getCKC:keyServerResponse];
    }
    return nil;
}

- (NSString *)getSPCMessageToKeyServer:(NSString *)spcData {
    if (self.delegate && [self.delegate respondsToSelector:@selector(getSPCMessageToKeyServer:)]) {
        return [self.delegate getSPCMessageToKeyServer:spcData];
    }
    return nil;
}

#pragma mark - Thumbnails

- (void)setThumbnailDelegate:(id<CLThumbsDelegate>)delegate {
    thumbsDelegate = delegate;
}

- (void)setThumbnailWithGridResource:(CLGridThumbnail *)gridThumb {
    gridThumbnails = gridThumb;
}

- (void)setThumbnailWithBifFile:(NSString *)path {
    bifFilepath = path;
}

- (void)setThumbnailWithWebVTTFile:(NSString *)path {
    webVTTFilepath = path;
}

- (void) toggleTracksView {
    if (!trackTableView) {
        if ([self.player state] == STATE_LOADING) {
            [self showWarningAlertWhilePlayerLoads];
            return;
        }
        CGRect rect = [self calculateTrackTableSizeForItemsCount:[self.player numberOfAudioTracks]];
        
        trackTableView = [[UITableView alloc] initWithFrame:rect style:UITableViewStyleGrouped] ;
        trackTableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [trackTableView setDataSource:self];
        [trackTableView setDelegate:self];
        trackTableView.backgroundColor = controlsBackgroundColor;
        [trackTableView setSeparatorColor:[UIColor whiteColor]];
        [self.view addSubview:trackTableView];
        [trackTableView setHidden:YES];
    }
    trackTableView.frame = [self calculateTrackTableSizeForItemsCount:[self.player numberOfAudioTracks]];
    [trackTableView setHidden:!trackTableView.isHidden];
}

- (void) loadTracksInfo {
    trackInformation = [NSMutableDictionary dictionary];
    NSMutableArray* videoQualities = [NSMutableArray array];
    [videoQualities addObject:[CLVideoTrackQuality new]];
    videoTrackDescription = [self.player describeVideoTrack];
    if (videoTrackDescription) {
        [videoQualities addObjectsFromArray:videoTrackDescription.qualities];
        [trackInformation setObject:videoQualities forKey:VIDEO_QUALITIES];

        NSUInteger i = 0;
        for (CLVideoTrackQuality *quality in videoTrackDescription.qualities) {
            cl_log("Codecs: VideoTrack: quality %lu codec %@", (unsigned long)i, quality.codec);
            ++i;
        }
    }
    NSMutableArray *audioTracks = [NSMutableArray array];
    for (int i = 0; i < [self.player numberOfAudioTracks]; i ++) {
        CLPlayerAudioTrack *audioTrack = [self.player describeAudioTrack:i];
        [audioTracks addObject:audioTrack];
        cl_log("Codecs: AudioTrack: %lu codec %@", (unsigned long)i, audioTrack.codec);
    }

    subTracks = [NSMutableArray array];
    NSMutableArray* nonForcedSubTracks = [NSMutableArray array];
    for (int i = 0; i < [self.player numberOfSubtitlesTracks]; i ++) {
        CLPlayerSubtitleTrack* desc = [self.player describeSubtitleTrack:i];
        if (desc == nil) {
            continue;
        }

        [subTracks addObject:desc];
        if (!desc.forced) {
            [nonForcedSubTracks addObject:desc];
        }
    }
    if ([audioTracks count] > 0) {
        [trackInformation setObject:audioTracks forKey:AUDIO_TRACKS];
    }
    if ([subTracks count] > 0) {
        // Menu entry for: disable subtitles
        CLPlayerSubtitleTrack* disableSubsMenuEntry = [CLPlayerSubtitleTrack new];
        disableSubsMenuEntry.title = @"Disable";
        disableSubsMenuEntry.trackIndex = TRACK_MENU_ENTRY_DISABLE_KEY;
        [nonForcedSubTracks addObject:disableSubsMenuEntry];
        // Menu entry for: show-only forced subtitles
        CLPlayerSubtitleTrack* showOnlyForcedMenuEntry = [CLPlayerSubtitleTrack new];
        showOnlyForcedMenuEntry.title = @"Show only forced";
        showOnlyForcedMenuEntry.trackIndex = TRACK_MENU_ENTRY_FORCED_SUBTITLES_KEY;
        [nonForcedSubTracks addObject:showOnlyForcedMenuEntry];
        // We want to show in the menu only the non-forced tracks
        [trackInformation setObject:nonForcedSubTracks forKey:SUBS_TRACKS];
    }
}

-(CGRect) calculateTrackTableSizeForItemsCount:(NSUInteger) count{
    int height = 100 + ((int)count) * 20; // Add subtitles
    int maxHeight = 200;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
        maxHeight = 400;
    }
    height = MIN(height,maxHeight);
    int width = 300;
    int x = _topControls.frame.origin.x + _topControls.frame.size.width - width;
    int y = _topControls.frame.origin.y + _topControls.frame.size.height;
    
    return CGRectMake(x, y, width, height);
}

@end

#pragma mark - Table view data source
#pragma clang diagnostic ignored "-Wprotocol"
@implementation CLPlayerViewController (AudioTrackSelection)

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSArray * keys = [[trackInformation allKeys] sortedArrayUsingSelector: @selector(caseInsensitiveCompare:)];
	NSString *key = [keys objectAtIndex:section];
	if ([key isEqualToString:AUDIO_TRACKS]) {
		return NSLocalizedString(@"Audio Tracks", nil);
	} else if ([key isEqualToString:SUBS_TRACKS]) {
		return NSLocalizedString(@"Subtitles", nil);
    } else if ([key isEqualToString:VIDEO_QUALITIES]) {
        return NSLocalizedString(@"Video Qualities", nil);
    }
	return @"";
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
	UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
	[header.textLabel setTextColor:[UIColor whiteColor]];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if ([[trackInformation allKeys] count] > 0) {
        tableView.backgroundView = nil;
        tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        return [[trackInformation allKeys] count];
    } else {
        UILabel* messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, tableView.bounds.size.height)];
        messageLabel.text = @"No info about tracks";
        messageLabel.textColor = [UIColor whiteColor];
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = NSTextAlignmentCenter;
        [messageLabel sizeToFit];
        tableView.backgroundView = messageLabel;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        return 0;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray * keys = [[trackInformation allKeys] sortedArrayUsingSelector: @selector(caseInsensitiveCompare:)];
    NSString *key = [keys objectAtIndex:section];
    NSMutableArray *tracks = [trackInformation objectForKey:key];
    return [tracks count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSArray * keys = [[trackInformation allKeys] sortedArrayUsingSelector: @selector(caseInsensitiveCompare:)];
	NSString *sectionKey = [keys objectAtIndex:indexPath.section];
	
	static NSString *CellIdentifier = @"Cell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (!cell) {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
		cell.backgroundColor = controlsBackgroundColor;
	}
	
	// Check mark
	NSUInteger currentOption = -1;
	if ([sectionKey isEqualToString:AUDIO_TRACKS]) {
		currentOption = [self.player currentAudioTrackIndex];
	} else if ([sectionKey isEqualToString:SUBS_TRACKS]) {
		currentOption = [self.player currentSubtitleTrackIndex];
        NSArray* disaplayedSubTracks = [trackInformation objectForKey:SUBS_TRACKS];
        bool foundInMenu = false;
        for (int i = 0; i < disaplayedSubTracks.count; i++) {
            CLPlayerSubtitleTrack* desc = [disaplayedSubTracks objectAtIndex:i];
            if (desc.trackIndex == currentOption) {
                foundInMenu = true;
                currentOption = i;
                break;
            }
        }
        // If the selected subtitle track it's not among the menu entries
        // (e.g. was filtered out because it's forced)
        // do not mark it as selected in the menu list
        if (!foundInMenu) {
            currentOption = -1;
        }
    } else if ([sectionKey isEqualToString:VIDEO_QUALITIES]) {
        currentOption = [self.player getSelectedVideoQuality] + 1; 
    }
    
	cell.accessoryType = currentOption == indexPath.row ?
							UITableViewCellAccessoryCheckmark :
							UITableViewCellAccessoryNone;
	
	// Label
    NSMutableString *text = [NSMutableString string];
    if ([sectionKey isEqualToString:AUDIO_TRACKS] || [sectionKey isEqualToString:SUBS_TRACKS]) {
        NSMutableArray *tracks = [trackInformation objectForKey:sectionKey];
        CLPlayerTrackWithLanguageAndIndex *trackDescription = [tracks objectAtIndex:indexPath.row];

        if ([self.delegate respondsToSelector:@selector(textForTrackDescription:)]) {
            NSString *overriden = [self.delegate textForTrackDescription:trackDescription];
            if (overriden) {
                [text appendString:overriden];
            }
        }

        if (text == nil || [text isEqualToString:@""]) {
            if (trackDescription.title && ![trackDescription.title isEqualToString:@""] && trackDescription.language && ![trackDescription.language isEqualToString:@""]) {
                [text appendFormat:@"%@ - %@", trackDescription.title, trackDescription.language];
            } else if (trackDescription.title && ![trackDescription.title isEqualToString:@""]) {
                [text appendString:trackDescription.title];
            } else if (trackDescription.language && ![trackDescription.language isEqualToString:@""]) {
                [text appendString:trackDescription.language];
            } else {
                [text appendFormat:@"%ld", (long)indexPath.row];
            }

            if (trackDescription.format && ![trackDescription.format isEqualToString:@""]) {
                [text appendFormat:@" (%@)", trackDescription.format];
            }
            if (trackDescription.trackIndex == TRACK_MENU_ENTRY_FORCED_SUBTITLES_KEY) {
                cell.textLabel.font = [UIFont italicSystemFontOfSize:cell.textLabel.font.pointSize];
                [text setString:@"Display forced subtitles"];
                if (self.subtitleMode != kSubtitleDisplayModeNone) {
                    cell.accessoryType = UITableViewCellAccessoryCheckmark;
                } else {
                    cell.accessoryType = UITableViewCellAccessoryNone;
                }
            } else  if (trackDescription.trackIndex == TRACK_MENU_ENTRY_DISABLE_KEY) {
                cell.accessoryType = currentOption == -1 ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
            }
        }
    } else if ([sectionKey isEqualToString:VIDEO_QUALITIES]) {
        NSMutableArray *tracks = [trackInformation objectForKey:sectionKey];
        if (indexPath.row == 0) {
            [text appendFormat:@"Automatic"];
        } else {
            CLVideoTrackQuality *qualityDescription = [tracks objectAtIndex:indexPath.row];
            [text appendFormat:@"- %lld (%dx%d)", qualityDescription.bitrate, qualityDescription.width, qualityDescription.height];
        }
    }
	cell.textLabel.text = text;
    cell.textLabel.textColor = [UIColor whiteColor];
	
	return cell;
}

-(NSString*)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section   {
	
	NSString *message = @"";
    NSArray * keys = [[trackInformation allKeys] sortedArrayUsingSelector: @selector(caseInsensitiveCompare:)];
	NSString *key = [keys objectAtIndex:section];
	NSInteger numberOfRowsInSection = [keys count];
	if (numberOfRowsInSection == 0) {
		if ([key isEqualToString:AUDIO_TRACKS]) {
			return NSLocalizedString(@"No Audio Track Info", nil);
		} else if ([key isEqualToString:SUBS_TRACKS]) {
			return NSLocalizedString(@"No Subtitle Info", nil);
		}
	}
	return message;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSArray * keys = [[trackInformation allKeys] sortedArrayUsingSelector: @selector(caseInsensitiveCompare:)];
	NSString *key = [keys objectAtIndex:indexPath.section];
	if ([key isEqualToString:AUDIO_TRACKS]) {
		StateID state = [self.player state];
		if (STATE_SEEKING != state) {
			playOnReady = (STATE_PLAYING == state);
		}
		[self.player selectAudioTrack:indexPath.row];
	} else if ([key isEqualToString:SUBS_TRACKS]) {
        NSArray* subs = [trackInformation objectForKey:SUBS_TRACKS];
        CLPlayerSubtitleTrack* desc = [subs objectAtIndex:indexPath.row];
        if (desc.trackIndex == TRACK_MENU_ENTRY_FORCED_SUBTITLES_KEY) {
            if (self.subtitleMode == kSubtitleDisplayModeNone) {
                self.subtitleMode = kSubtitleDisplayModeOnlyForced;
            } else {
                self.subtitleMode = kSubtitleDisplayModeNone;
            }
            [self automaticSubtitleSelection];
        } else   if (desc.trackIndex == TRACK_MENU_ENTRY_DISABLE_KEY) {
            [self.player selectSubtitleTrack:-1];
            // After disabling the subs, run again the automatic subtitle selection algorithm
            if (self.subtitleMode == kSubtitleDisplayModeOnlyForced) {
                [self automaticSubtitleSelection];
            }
        } else {
            [self.player selectSubtitleTrack:desc.trackIndex];
        }
    } else if ([key isEqualToString:VIDEO_QUALITIES]) {
        [self.player selectVideoQuality:(int)indexPath.row - 1]; // We take into account the first row which is "Automatic"
    }
	[trackTableView reloadData];
}

#pragma mark - AVPictureInPictureControllerDelegate

bool pictureInPitcureWasPlaying = false;

- (void)pictureInPictureControllerWillStopPictureInPicture:(AVPictureInPictureController *)pictureInPictureController {
    pictureInPitcureWasPlaying = (pipController.playerLayer.player.rate > 0);
}

- (void)pictureInPictureControllerDidStopPictureInPicture:(AVPictureInPictureController *)pipController {
    if (pictureInPitcureWasPlaying) {
        [self.player play];
    }
    pictureInPitcureWasPlaying = false;
}

- (void)pictureInPictureController:(AVPictureInPictureController *)pictureInPictureController failedToStartPictureInPictureWithError:(NSError *)error {
    cl_log_error("Failed to start picture in picture");
}

#pragma mark - CLChromecastDelegate

- (void)addChromecastMiniController:(UIViewController *)miniMediaController {
    [self addChildViewController:miniMediaController];
    miniMediaController.view.frame = self.chromecastMinicontrollerParent.bounds;
    [self.chromecastMinicontrollerParent addSubview:miniMediaController.view];
    [miniMediaController didMoveToParentViewController:self];
}

- (void)addChromecastButton:(UIButton *)castButton {
    [self.chromecastButtonParent addSubview:castButton];
}

- (void)chromecastMiniControllerShouldAppear:(bool)shouldAppear {
    self.chromecastMinicontrollerParent.hidden = !shouldAppear;
}

- (void)onChromecastConnection:(bool)active {
    if (active) {
        [self.player pause];
        self.bottomControls.userInteractionEnabled = false;
    } else {
        self.bottomControls.userInteractionEnabled = true;
        bool paused = ([self.chromecast getState] == ChromecastPlayerStatePaused);
        // Resume locally from where the remote playback stopped
        if (!paused) {
            [self.player play];
            CMTime pos = [self.chromecast getLastKnownPositionInSeconds];
            if (CMTIME_IS_VALID(pos)) {
                [self.player seek:pos];
            }
        }
    }
}

- (void) onChromecastSessionStart {
    [self stopAdSession];
}

- (void) onChromecastSessionStop {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.bottomControls.userInteractionEnabled = true;
    });

    if (self.adsServer && !self.adsSession) {
        [self startAdSession];
        [self.adsSession setPlayAdsAfterTime:CMTimeGetSeconds([self.chromecast getLastKnownPositionInSeconds])];
    }
}

@end
