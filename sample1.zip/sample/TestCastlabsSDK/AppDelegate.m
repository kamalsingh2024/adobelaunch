//
//  AppDelegate.m
//  TestCastlabsSDK
//
//  Created by Guido Parente on 23/02/2016.
//  Copyright © 2016 castlabs. All rights reserved.
//

#import "AppDelegate.h"
#include <mach-o/dyld.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	// If you are collecting crash dumps, make sure to retrieve the load addresses of castLabs frameworks
    // in case you have a trace to forward to castLabs to be symbolicated.
    NSMutableDictionary *loadAddresses = [NSMutableDictionary dictionaryWithCapacity:10];
    uint32_t numImages = _dyld_image_count();
    for (uint32_t i = 0; i < numImages; i++) {
        const struct mach_header *header = _dyld_get_image_header(i);
        NSString *name = [NSString stringWithUTF8String: _dyld_get_image_name(i)];
        if ([name containsString:@"Castlabs"]) {
            name = [name  substringFromIndex:[name rangeOfString:@"Castlabs" options:NSBackwardsSearch].location];
            [loadAddresses setObject:[NSString stringWithFormat:@"%p",  header] forKey:name];
        }
    }
    // If you are using Crashlytics, this will attach load adresses to dumps
    // [[Crashlytics sharedInstance] setObjectValue:[loadAddresses description] forKey:@"castLabs load addresses"];
    NSLog(@"castLabs load addresses: %@", [loadAddresses description]);
	return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
