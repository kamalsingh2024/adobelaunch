//
//  ViewController.h
//  TestCastlabsSDK
//
//  Copyright © 2016 castlabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)onStartPlayback:(id)sender;

@end

