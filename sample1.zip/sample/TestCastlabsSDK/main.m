//
//  main.m
//  TestCastlabsSDK
//
//  Created by Guido Parente on 23/02/2016.
//  Copyright © 2016 castlabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
