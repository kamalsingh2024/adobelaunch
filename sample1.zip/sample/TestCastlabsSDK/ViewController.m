//
//  ViewController.m
//  TestCastlabsSDK
//
//	Copyright © 2016 castlabs. All rights reserved.
//

#import "ViewController.h"
#import <CastlabsSDK/CastlabsSDK.h>
#import <CastlabsSDK/CLPlayerViewController.h>
#import <CastlabsConviva/CastlabsConviva.h>

//#import <CastlabsDASH/CastlabsDASH.h>
//#import <CastlabsOMA/CastlabsOMA.h>
//#import <CastlabsSubtitles/CastlabsSubtitles.h>
//#import <CastlabsStreamDownloader/CastlabsStreamDownloader.h>
//#import <CastlabsYoubora/CastlabsYoubora.h>
//#import <CastlabsIMA/CastlabsIMA.h>
//#import <Castlabs360/Castlabs360.h>
NSString* streamURL = @"http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8";
//NSString* dashURL = @"http://demo.cf.castlabs.com/media/TOS/abr/Manifest_clean_sizes.mpd";

@interface ViewController() /*<CLMovieDownloadSetDelegate>*/ {
	
}
@end

@implementation ViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	
    NSDictionary *conviva = @{@"accountCode":@"2b7c637964bded3629e188dbd9a6be90803eefaa",@"gatewayUrl": @"http://telstra-test.testonly.conviva.com"};
      

      CastlabsConviva *ca = [[CastlabsConviva alloc ] initWithKeys:(conviva)];
      
      NSArray *myColors;

      myColors = [NSArray arrayWithObjects: ca,nil];
      
      
      
      NSLog(@"***************accountCode:%@", [conviva objectForKey:@"accountCode"]);
      NSLog(@"***************gatewayUrl:%@", [conviva objectForKey:@"gatewayUrl"]);
    
	[CastlabsSDK with:@[//[CastlabsDASH alloc],
						//[CastlabsOMA alloc],
						//[CastlabsSubtitles alloc],
						//[[CastlabsYoubora alloc] initWithKeys:@{@"accountCode": @""}],
        myColors
						//[CastlabsIMA alloc],
						//[CastlabsStreamDownloader alloc],
						//[Castlabs360 alloc]
						//[[CastlabsChromecast alloc] initWithReceiverId:@""]
						]
		andLicenseKey:@"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJidW5kbGVJZCI6ImNvbS50ZWxzdHJhLm1lZGlhLnRlbHN0cmFnZyIsImtpZCI6MjY2NSwiaWx2IjpmYWxzZX0.gekkyNihWNzFb8I_f-KTt1YeMCCEgH4cUwE8veOg8RzXXHgQ_fXgI8qPNo2x37qSKJxhte0WcMlQFgoAtSO9eHpid1WAr5Gp98jhFgESR92NI1wMCX-8s0_nhkJg3JwI6Irm68DisYTuvFKJKhmIpPXQC1lsSJxznUxhL3qhKzrGLZxarbXPt5WrQuYA_u8dchQ3QlhVhnfDEmrOYoy-awUrTb8PdfSGEOiUaSnvk2EeyEve1uEktptCiTGkinXeY7WrHtJ-v6D1N1jACmrMN4zVOL3YSh5oJT-A5POe_r0c2L0lSZsrTaww1z7xDyUDcT8Ucb-_2iJxG4OsNT25wg"
	 andDelegate:nil
	 ];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
}

+ (NSString *)applicationDocumentsDirectory {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}

- (void)onStartPlayback:(id)sender {
	UIStoryboard *sdkStoryboard = [UIStoryboard storyboardWithName:@"CLSDKStoryboard" bundle:[NSBundle bundleWithIdentifier:@"castlabs.CastlabsSDK"]];
	CLPlayerViewController *vc = [sdkStoryboard instantiateViewControllerWithIdentifier:@"CLPlayerViewController"];
	vc.streamUrl = streamURL;
	vc.metadata = [[CLContentMetadata alloc] init];
	vc.metadata.title = @"castLabs example stream";
	CLDrmConfiguration * configuration = [[CLDrmConfiguration alloc] init];
	configuration.assetId = @"...";
	configuration.merchantId = @"...";
	configuration.sessionId = @"...";
	configuration.userId = @"...";
	configuration.environment = kProduction;
	configuration.type = kDrmOma;
	configuration.tempDirectory = [ViewController applicationDocumentsDirectory];
	configuration.workingDirectory = NSTemporaryDirectory();
	//vc.drmConfiguration = configuration; //Uncomment this line to add your DRMConfiguration to the player
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    // [vc addSubtitlesTrackFromUrl:[NSURL URLWithString:@"https://demo.cf.castlabs.com/media/QA/hls-short-multiaudio-multisub/sub/120min_EN.vtt"] withFormat:kSubtitleWebVTT withDisplayName:@"New Sub" withLanguageCode:@"New Lang"];
	[self presentViewController:vc animated:YES completion:nil];
	//[self startDownload];
}
/*
- (void)startDownload {
	NSLog(@"-- Get available qualties...");
	
	// Get download instance
	//
	// The shared downloader instance does not allow downloads over the cellular network and operates in
	// discretionary mode (allowing iOS to schedule the downloads for optimal performance). If other
	// characteristics are required a custom downloader can be created and manually maintained using the
	// regular alloc/init APIs (see the header documentation for API details).
	CLMovieDownloader* downloader = [CLMovieDownloader sharedDownloader];

	// Custom headers may be added for all requests from the downloader
	downloader.additionalHeaders = @{@"Header": @"Downloader-Value",
									 @"AnotherHeader": @"Downloader-Value"
									 };

	// Fetch stream qualities
	NSMutableArray* audioTrackQualities = [NSMutableArray array];
	NSMutableArray* videoTrackQualities = [NSMutableArray array];
	NSMutableArray* subTrackQualities = [NSMutableArray array];
	[downloader fetchDownloadSetForURL:dashURL
					   completionBlock:^(CLMovieDownloadSet* downloadSet,
										 NSError* error) {
						   NSLog(@"-- Qualities list downloaded");
						   if (downloadSet) {
							   // Uncomment this to force download every time, if not the qualities may
							   // already be downloaded & cached on disk so no download will actually
							   // take place
							   //[downloadSet removeAllDownloadedQualities];
							   for (CLTrack* track in downloadSet.movie.audioTracks) {
								   for (CLQuality* quality in track.qualities) {
									   [audioTrackQualities addObject:quality];
									   NSLog(@"--- audio : %@", quality.parameters);
								   }
							   }
							   for (CLTrack* track in downloadSet.movie.videoTracks) {
								   for (CLQuality* quality in track.qualities) {
									   [videoTrackQualities addObject:quality];
									   NSLog(@"--- video : %@", quality.parameters);
								   }
							   }
							   for (CLTrack* track in downloadSet.movie.textTracks) {
								   for (CLQuality* quality in track.qualities) {
									   [subTrackQualities addObject:quality];
									   NSLog(@"--- subtitles : %@", quality.parameters);
								   }
							   }
							   
							   // Choose the qualities to download (in this example we just choose the
							   // first one of each track type)
							   CLQuality* audioQuality = [audioTrackQualities objectAtIndex:0];
							   NSLog(@"-- Set Audio Quality with %@", audioQuality.parameters);
							   [downloadSet selectQuality:audioQuality];
							   
							   CLQuality* videoQuality = [videoTrackQualities objectAtIndex:0];
							   NSLog(@"-- Set Video Quality with %@", videoQuality.parameters);
							   [downloadSet selectQuality:videoQuality];
							   
							   CLQuality* subQuality = [subTrackQualities objectAtIndex:0];
							   NSLog(@"-- Set sub Quality with %@", subQuality.parameters);
							   [downloadSet selectQuality:subQuality];

							   // Custom headers may be added for the download set (overriding additional
							   // headers using the same key from the downloader).
							   downloadSet.additionalHeaders = @{@"AnotherHeader": @"Set-Value"};

							   [self downloadStreamWithCLMovieDownloadSet:downloadSet];
						   } else {
							   NSLog(@"Failed to load qualities: %@", error);
						   }
					   }];
}

- (void)downloadStreamWithCLMovieDownloadSet:(CLMovieDownloadSet*)downloadSet {
	NSLog(@"-- Start stream download");
	// Add the optional DRM params
	//[_downloadSet.properties setObject:someAssetId forKey:@"assetId"];
	//[_downloadSet.properties setObject:someMerchantId forKey:@"merchantId"];
	//[_downloadSet.properties setObject:someUserId forKey:@"userId"];
	//[_downloadSet.properties setObject:someSessionId orKey:@"sessionId"];
	
	// Monitor progress
	downloadSet.delegate = self;
	
	// Start download
	CLMovieDownloader* downloader = [CLMovieDownloader sharedDownloader];
	[downloader download:downloadSet];
}

#pragma mark CLMovieDownloadSetDelegate

- (void)movieDownloadSet:(nonnull CLMovieDownloadSet*)set didChangeStatus:(CLDownloadSetStatus)status {
	NSLog(@"movieDownloadSet: %@, didChangeStatus: %ld", set.movie.name, (long)status);
	// Do any processing necessary on set state change
}

- (void)movieDownloadSet:(CLMovieDownloadSet*)set didCompleteWithError:(nullable NSError*)error {
	NSLog(@"movieDownloadSet: %@, didCompleteWithError: %@", set.movie.name, error);
	// Do any processing necessary on set completion/failure
}

- (void)movieDownloadSet:(CLMovieDownloadSet*)set didUpdateProgress:(CLDownloadProgress)progress {
	NSLog(@"movieDownloadSet:%@ didUpdateProgress:%.2f [%lld/%lld]", set.movie.name, set.downloadedBytes, set.expectedBytes);
	// Do any processing necessary on set progress updates
}
*/

@end
