//
//  ViewController.swift
//  TestCastlabsSDKSwift
//
//  Created by Guido Parente on 14/07/2017.
//  Copyright © 2017 castlabs. All rights reserved.
//

import UIKit

import CastlabsSDK
import CastlabsConviva


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let castl = CastlabsConviva(keys: [AnyHashable("accountCode"):"2b7c637964bded3629e188dbd9a6be90803eefaa",AnyHashable("gatewayUrl"): "http://info.telstra.com.au"])
        
   
          CastlabsSDK .with([castl as Any], andLicenseKey: "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJidW5kbGVJZCI6ImNvbS50ZWxzdHJhLm1lZGlhLnRlbHN0cmFnZyIsImtpZCI6MjY2NSwiaWx2IjpmYWxzZX0.gekkyNihWNzFb8I_f-KTt1YeMCCEgH4cUwE8veOg8RzXXHgQ_fXgI8qPNo2x37qSKJxhte0WcMlQFgoAtSO9eHpid1WAr5Gp98jhFgESR92NI1wMCX-8s0_nhkJg3JwI6Irm68DisYTuvFKJKhmIpPXQC1lsSJxznUxhL3qhKzrGLZxarbXPt5WrQuYA_u8dchQ3QlhVhnfDEmrOYoy-awUrTb8PdfSGEOiUaSnvk2EeyEve1uEktptCiTGkinXeY7WrHtJ-v6D1N1jACmrMN4zVOL3YSh5oJT-A5POe_r0c2L0lSZsrTaww1z7xDyUDcT8Ucb-_2iJxG4OsNT25wg", andDelegate: nil);
            
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let bundle = Bundle(identifier: "castlabs.CastlabsSDK")
        let storyboard = UIStoryboard(name: "CLSDKStoryboard", bundle: bundle)
        let vc = storyboard.instantiateViewController(withIdentifier: "CLPlayerViewController") as! CLPlayerViewController
        
        
        let met = CLContentMetadata(contentAssetId: "assetid:123", title: "Tile123", isLive: false)
        
            
        vc.metadata = met
        
        //vc.streamUrl = "http://kamalsingh29.github.io/adobelaunch/SampleVideo_1280x720_1mb.mp4"

        vc.streamUrl = "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"
        
        //vc.streamUrl = "http://vm2.dashif.org/livesim/testpic_2s/Manifest.mpd"
        
        self.present(vc, animated: true, completion: nil)
    }

    
}

