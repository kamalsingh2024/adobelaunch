//
//  CLAppleTVPlayerViewController.m
//  CastlabsSDK
//
//  Created by Emil Pettersson on 25/01/16.
//  Copyright © 2016 castLabs. All rights reserved.
//

#import "CLAppleTVPlayerViewController.h"

#import "CLPanelViewController.h"
#import "CLSeekBar.h"
#import "CLChromeViewController.h"

#import "CGHelpers.h"

#import "CLPlayerFactory.h"
#import "CLPlayerUtils.h"
#import "CLDrmConfiguration.h"
#import "CLLog.h"
#import "CLWeakInstance.h"
#import "CLUtils.h"
#import "NSArray+Utils.h"

#define CLPANEL_Y_MAX 720.0

#pragma mark -

@interface CLAppleTVPlayerViewController () <UIGestureRecognizerDelegate, CLPanelDelegate, CLChromeDelegate, CLPlayerListenerProtocol, CLAdsListener> {

    IBOutlet UITapGestureRecognizer* remoteSelectRecognizer;
    IBOutlet UITapGestureRecognizer* remoteMenuRecognizer;
    IBOutlet UITapGestureRecognizer* remotePlayPauseRecognizer;
    IBOutlet UITapGestureRecognizer* remoteRewindRecognizer;
    IBOutlet UITapGestureRecognizer* remoteForwardRecognizer;
    IBOutlet UITapGestureRecognizer* remoteUpRecognizer;
    IBOutlet UITapGestureRecognizer* remoteDownRecognizer;
    IBOutlet UIPanGestureRecognizer* remotePanRecognizer;

    __weak IBOutlet UIView* panelContainerView;
    __weak IBOutlet NSLayoutConstraint* panelTopConstraint;
    __weak IBOutlet NSLayoutConstraint* panelHeightConstraint;

    __weak IBOutlet UIActivityIndicatorView* activityIndicator;

    NSUInteger audioChannels;

    CLAdSession* adsSession;
    bool isAdsPlaying;
}

@property(nullable, nonatomic, readwrite) id<CLPlayer> player;
@property(strong, nonatomic) CLPanelViewController *panel;
@property(strong, nonatomic) CLChromeViewController *chrome;

@property (nullable, weak, nonatomic) IBOutlet UIView *chromeContainerView;

// Enable ads playback
@property(nullable, nonatomic) NSString *adsAssetId;

// store the titles that will be added to the menu for customisation.
@property(nullable, nonatomic, strong) NSArray <NSString *> *customMenuTitles;

@end

#pragma mark -

@implementation CLAppleTVPlayerViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Prepare gesture recognizers
    remoteSelectRecognizer.enabled = YES;
    remoteMenuRecognizer.enabled = YES;
    remotePlayPauseRecognizer.enabled = YES;
    remoteRewindRecognizer.enabled = YES;
    remoteForwardRecognizer.enabled = YES;
    remoteUpRecognizer.enabled = NO;
    remoteDownRecognizer.enabled = YES;
    remotePanRecognizer.enabled = YES;

    // Prepare the top panel
    self.panel = self.childViewControllers.firstObject;
    if (self.customMenuTitles.count > 0) {
        [self.panel addMenuItems:self.customMenuTitles];
    }
    
    self.panel.delegate = self;

    panelContainerView.userInteractionEnabled = NO;
    [self.panel panelWillHide];
    panelTopConstraint.constant = -panelContainerView.frame.size.height;
    [self.panel panelDidHide];

    // Prepare the seek bar
    if ([self.childViewControllers containsIndex:1]) {
        self.chrome = [self.childViewControllers objectAtIndex:1];
    }
    
    self.chrome.delegate = self;

    self.chromeContainerView.userInteractionEnabled = NO;
    [self.chrome chromeWillHide];
    self.chromeContainerView.alpha = 0.0;
    [self.chrome chromeDidHide];
}

- (void)viewDidAppear:(BOOL)animated {
    if (self.streamUrl == nil) {
        [self onError:CL_ERROR_UNKNOWN withMessage:@"No URL specified"];
        return;
    }

    [activityIndicator startAnimating];

    CLPlayerFactory* factory = [[CLPlayerFactory alloc] init];
    self.player = [factory createPlayerWithStreamUrl:self.streamUrl
                                 andDrmConfiguration:self.drmConfiguration
                                      andContentType:self.contentType];
    if (self.player == nil) {
        [self onError:CL_ERROR_UNKNOWN withMessage:@"Failed to instantiate SDK player"];
        return;
    }
    [self.player addListener:self];

    // NOTE: Player will change its state to STATE_READY when ready to play
    [self.player open];
    if (self.player == nil) {
        isAdsPlaying = false;
    }

    [super viewDidAppear:animated];
}

#pragma mark - Focus

- (UIView*)preferredFocusedView {
    return self.panel.isShown ? [self.panel preferredFocusedView] : [super preferredFocusedView];
}


- (void)didUpdateFocusInContext:(UIFocusUpdateContext*)context withAnimationCoordinator:(UIFocusAnimationCoordinator*)coordinator {
    if (nil == context.previouslyFocusedView) {
        if ([context.nextFocusedView isDescendantOfView:self.panel.view]) {
            remoteSelectRecognizer.enabled = NO;
            remoteRewindRecognizer.enabled = NO;
            remoteForwardRecognizer.enabled = NO;
            remoteUpRecognizer.enabled = [context.nextFocusedView isDescendantOfView:self.panel.tabBar];
            remoteDownRecognizer.enabled = NO;
            remotePanRecognizer.enabled = remoteUpRecognizer.enabled;
        }
    } else if ([context.previouslyFocusedView isDescendantOfView:self.panel.view]) {
        if (nil == context.nextFocusedView) {
            remoteSelectRecognizer.enabled = YES;
            remoteRewindRecognizer.enabled = YES;
            remoteForwardRecognizer.enabled = YES;
            remoteUpRecognizer.enabled = NO;
            remoteDownRecognizer.enabled = YES;
            remotePanRecognizer.enabled = YES;
        } else {
            remoteUpRecognizer.enabled = [context.nextFocusedView isDescendantOfView:self.panel.tabBar];
            remotePanRecognizer.enabled = remoteUpRecognizer.enabled;
        }
    }
    [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];
}

#pragma mark - Top Panel

- (BOOL)showPanel {
    if (![self.panel panelShouldShow]) {
        return NO;
    }
    if ([self.delegate respondsToSelector:@selector(onMenuPanelShown)]) {
        [self.delegate onMenuPanelShown];
    }
    
    [self.panel panelWillShow];
    panelContainerView.userInteractionEnabled = YES;
    [self setNeedsFocusUpdate];

    [self.view layoutIfNeeded];
    panelTopConstraint.constant = 0;
    weakify(self);
    [UIView animateWithDuration:.25
                     animations:^{
                         strongify(self);
                         [self.view layoutIfNeeded];
                     }
                     completion:^(BOOL finished) {
                         if (finished) {
                             strongify(self);
                             [self.panel panelDidShow];
                             [self hideChrome];
                         }
                     }];
    return YES;
}

- (BOOL)hidePanel {
    if (![self.panel panelShouldHide]) {
        return NO;
    }
    if ([self.delegate respondsToSelector:@selector(onMenuPanelDismiss)]) {
        [self.delegate onMenuPanelDismiss];
    }
    [self.panel panelWillHide];
    panelContainerView.userInteractionEnabled = NO;
    [self setNeedsFocusUpdate];

    [self.view layoutIfNeeded];
    panelTopConstraint.constant = -panelContainerView.frame.size.height;
    weakify(self)
    [UIView animateWithDuration:.25
                     animations:^{
                         strongify(self);
                         [self.view layoutIfNeeded];
                     }
                     completion:^(BOOL finished) {
                         if (finished) {
                             strongify(self)
                             [self.panel panelDidHide];
                             if (STATE_PAUSED == self.player.state) {
                                 [self showChrome];
                             }
                         }
                     }];
    return YES;
}

#pragma mark - <UIContentContainer>

- (void)preferredContentSizeDidChangeForChildContentContainer:(id<UIContentContainer>)container {
    if (self.panel == container) {
        CGFloat height = container.preferredContentSize.height;
        if (CLPANEL_Y_MAX < height) {
            height = CLPANEL_Y_MAX;
        }
        panelHeightConstraint.constant = height;
    }
    [super preferredContentSizeDidChangeForChildContentContainer:container];
}

#pragma mark - <CLPanelDelegate>

#pragma mark - Chrome

- (BOOL)showChrome {
    if (self.panel.isShown) {
        return NO;
    }

    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideChrome) object:nil];

    if (![self.chrome chromeShouldShow]) {
        return NO;
    }
    [self.chrome chromeWillShow];
    
    // Set userInteractionEnabled only from the main thread
    if ([NSThread isMainThread]) {
        self.chromeContainerView.userInteractionEnabled = YES;
    } else {
        weakify(self)
        dispatch_sync(dispatch_get_main_queue(), ^{
            strongify(self)
            self.chromeContainerView.userInteractionEnabled = YES;
        });
    }

    [self setNeedsFocusUpdate];

    weakify(self)
    [UIView animateWithDuration:.25
                     animations:^{
                         strongify(self)
                         // Set alpha only from the main thread
                         if ([NSThread isMainThread]) {
                             self.chromeContainerView.alpha = 1.0;
                         } else {
                             dispatch_sync(dispatch_get_main_queue(), ^{
                                 strongify(self)
                                 self.chromeContainerView.alpha = 1.0;
                             });
                         }
                     }
                     completion:^(BOOL finished) {
                         if (finished) {
                             strongify(self)
                             [self.chrome chromeDidShow];
                         }
                     }];
    return YES;
}

- (BOOL)hideChrome {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideChrome) object:nil];

    if (![self.chrome chromeShouldHide]) {
        return NO;
    }
    [self.chrome chromeWillHide];
    self.chromeContainerView.userInteractionEnabled = NO;
    [self setNeedsFocusUpdate];

    weakify(self)
    [UIView animateWithDuration:.25
                     animations:^{
                         strongify(self)
                         self.chromeContainerView.alpha = 0.0;
                     }
                     completion:^(BOOL finished) {
                         if (finished) {
                             strongify(self)
                             [self.chrome chromeDidHide];
                         }
                     }];
    return YES;
}

- (BOOL)hideChromeDelayed {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideChrome) object:nil];

    if (!self.chrome.isShown) {
        return NO;
    }
    if (STATE_PAUSED == self.player.state) {
        return NO;
    }

    [self performSelector:@selector(hideChrome) withObject:nil afterDelay:5.0];
    return YES;
}

#pragma mark - <CLChromeDelegate>

- (void)chromeRequestsPlaybackHeadUpdate:(CLChromeViewController *)sender {
    CMTime head = self.player.position;
    if (!CMTIME_IS_INDEFINITE(head)) {
        sender.playbackHead = CMTimeGetSeconds(head);
    }
}

- (void)chromeRequestsDurationUpdate:(CLChromeViewController *)sender {
    CMTime duration = self.player.duration;
    if (!CMTIME_IS_INDEFINITE(duration)) {
        sender.duration = CMTimeGetSeconds(duration);
    }
}

- (void)chrome:(CLChromeViewController*)sender seekDidBeginWithHead:(CGFloat)head {
    [self.player pause];
}

- (void)chrome:(CLChromeViewController*)sender seekDidCancelWithHead:(CGFloat)head {
    [self.player play];
}

- (void)chrome:(CLChromeViewController*)sender seekDidConfirmWithHead:(CGFloat)head {
    [self.player seek:CMTimeMakeWithSeconds(head, 1000)];
    [self.player play];
}

#pragma mark - Taps & Gestures

- (void)touchesBegan:(NSSet<UITouch*>*)touches withEvent:(UIEvent*)event {
    [self showChrome];
    [super touchesBegan:touches withEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch*>*)touches withEvent:(UIEvent*)event {
    [self hideChromeDelayed];
    [super touchesBegan:touches withEvent:event];
}

- (IBAction)onRemoteSelect:(UITapGestureRecognizer*)sender {
    [self onRemotePlayPause:sender];
}

- (IBAction)onRemoteMenu:(UITapGestureRecognizer*)sender {
    if (UIGestureRecognizerStateEnded == sender.state) {
        if (![self hidePanel] && ![self hideChrome]) {
            if ([self.delegate respondsToSelector:@selector(willDismissWithPosition:)]) {
                [self.delegate willDismissWithPosition:self.player.position];
            }
            
            [self.player stop];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    }
}

- (IBAction)onRemotePlayPause:(UITapGestureRecognizer*)sender {
    if (UIGestureRecognizerStateEnded == sender.state) {
        if (![self.chrome confirmSeek]) {
            switch (self.player.state) {
                case STATE_PLAYING:
                    [self.player pause];
                    break;
                case STATE_PAUSED:
                    [self.player play];
                    break;
                default:
                    break;
            }
        }
    }
}

- (IBAction)onRemoteRewind:(UITapGestureRecognizer*)sender {
    if (UIGestureRecognizerStateEnded == sender.state) {
        if ([self.chrome seekWithOffset:-10.0]) {
            [self.chrome confirmSeek];
            if ([self.delegate respondsToSelector:@selector(onSeekingTo:)]) {
                [self.delegate onSeekingTo:self.player.position];
            }
        }
    }
}

- (IBAction)onRemoteForward:(UITapGestureRecognizer*)sender {
    if (UIGestureRecognizerStateEnded == sender.state) {
        if ([self.chrome seekWithOffset:10.0]) {
            [self.chrome confirmSeek];
            if ([self.delegate respondsToSelector:@selector(onSeekingTo:)]) {
                [self.delegate onSeekingTo:self.player.position];
            }
        }
    }
}

- (IBAction)onRemoteUp:(UIGestureRecognizer*)sender {
    if (remoteUpRecognizer.enabled && UIGestureRecognizerStateEnded == sender.state) {
        [self hidePanel];
    }
}

- (IBAction)onRemoteDown:(UIGestureRecognizer*)sender {
    if (remoteDownRecognizer.enabled && UIGestureRecognizerStateEnded == sender.state) {
        [self showPanel];
    }
}

- (IBAction)onRemotePan:(UIPanGestureRecognizer*)sender {
    CGPoint v = [sender velocityInView:self.view];
    // Determine if pan is (mostly) vertical or horizontal
    if (CGFloatAbs(v.x) < CGFloatAbs(v.y)) {
        // Vertical pan (Top Panel)
        if (0.0 < v.y) {
            [self onRemoteDown:sender];
        } else {
            [self onRemoteUp:sender];
        }
    } else {
        // Horizontal pan (Chrome)
        [self.chrome seekWithVelocity:v.x];
    }
}

- (void)dealloc {
    self.player = nil;
}

#pragma mark - CLPlayerListenerProtocol

- (void)initiatePlayback {
    // Update panel & chrome information
    self.panel.player = self.player;
    [self chromeRequestsPlaybackHeadUpdate:self.chrome];
    [self chromeRequestsDurationUpdate:self.chrome];

    weakify(self)
    // UI changes need to be done on main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        // Insert player layer into main view
        strongify(self)
        CALayer *layer = self.player.playerView;
        layer.frame = self.view.frame;

        if (layer.superlayer == nil) {
            // NOTE: do not insert same layer multiple times
            [self.view.layer insertSublayer:layer atIndex:0];
        }
    });

    if (self.adsAssetId && !adsSession) {
        [self startAdSession];
    } else {
        if (!isAdsPlaying) {
            // Start playing
            [self.player play];
        }
    }
}

- (void) startAdSession {
    adsSession = [CLAdSession createAdSession];
    if (adsSession) {
        adsSession = [adsSession initWithPlayer:self.player forViewController:self onView:self.view];
        NSLog(@"requestAd @ %@", self.adsAssetId);
        adsSession.apiKey = @"";
        [adsSession requestAds:self.adsAssetId];
        [self.player addAdListener:self];
    }
}

- (void) stopAdSession {
    if (adsSession) {
        [adsSession destroy];
        adsSession = nil;
        isAdsPlaying = false;
    }
}

#pragma mark - CLAdsListener

-(void)adStopped:(CLAdEvent *)event {
    // Not implemented
}

-(void)adStarted:(CLAdEvent *)event {
    // Not implemented
}

- (void)adsLoaded:(NSDictionary*) adsInfo {
    bool isPreroolAdPresent = false;
    NSArray* adCuepoints = [adsInfo objectForKey:@"adCuePoints"];
    for (NSNumber* adCuepoint in adCuepoints) {
        if (adCuepoint.integerValue == 0) {
            isPreroolAdPresent = true;
        }
    }
    if (!isPreroolAdPresent) {
        [self.player play];
    }
}

- (void)didRequestContentPause {
    isAdsPlaying = true;
    [self.player pause];
}

- (void)didRequestContentResume {
    isAdsPlaying = false;
    [self.player play];
}

- (void) onStateChangedTo:(StateID)state from:(StateID)oldState withData:(NSDictionary*)data{
    switch (state) {
        case STATE_PLAYING:
            [self hideChromeDelayed];
            [activityIndicator stopAnimating];
            break;
        case STATE_PAUSED:
            [self showChrome];
            break;
        case STATE_SEEKING:
            [activityIndicator startAnimating];
            break;
        case STATE_FINISHED:
            [self.player stopAnalyticsSession];
            [self showChrome];
            break;
        case STATE_READY:
            [self initiatePlayback];
            break;
        case STATE_STALLED:
            [activityIndicator startAnimating];
            break;
        case STATE_UNKNOWN:
            // fall-trough
        default:
            break;
    }
}

- (void)onError:(ErrorID)errorID withMessage:(NSString*)message {
    NSString* errorMessage = [CLPlayerUtils playerErrorToString:errorID];
    if (message) {
        message = [NSString stringWithFormat:@"%@ with message:%@", errorMessage, message];
    }
    cl_log_error("%@", errorMessage);

    weakify(self)
    // UI changes need to be done on main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController* alert = [UIAlertController
                                    alertControllerWithTitle:@"SDK Error"
                                    message:errorMessage
                                    preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction* defaultAction = [UIAlertAction
                                        actionWithTitle:@"OK"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction* action) {}];
        [alert addAction:defaultAction];
        strongify(self)
        [self presentViewController:alert animated:YES completion:nil];
    });
}

- (NSData *)getCKC:(NSData *)keyServerResponse {
    if (self.delegate && [self.delegate respondsToSelector:@selector(getCKC:)]) {
        return [self.delegate getCKC:keyServerResponse];
    }
    return nil;
}

- (NSString *)getSPCMessageToKeyServer:(NSString *)spcData {
    if (self.delegate && [self.delegate respondsToSelector:@selector(getSPCMessageToKeyServer:)]) {
        return [self.delegate getSPCMessageToKeyServer:spcData];
    }
    return nil;
}

- (void) onPlaybackInfo:(CLPlaybackInfo *)info {
    if (info.audioChannels > 0 && info.audioChannels != audioChannels) {
        cl_log("onPlaybackInfo audioChannels: %lu", (unsigned long)info.audioChannels);
        audioChannels = info.audioChannels;
    }
}

- (void)addMenuItems:(NSArray <NSString *> *)items {
    self.customMenuTitles = items;
}

- (void)menuItemSelected:(NSInteger)index {
   /* if ([self.delegate respondsToSelector:@selector(onMenuItemSelected:)]) {
        [self.delegate onMenuItemSelected:index];
    }*/
}

@end
