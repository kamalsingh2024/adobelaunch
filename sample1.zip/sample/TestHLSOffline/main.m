//
//  main.m
//  TestHLSOffline
//
//  Created by Guido Parente on 15/06/2017.
//  Copyright © 2017 castlabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
