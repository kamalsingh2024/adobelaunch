//
//  ViewController.m
//  HLSDownloadTest
//
//  Created by Guido Parente on 23/08/2017.
//  Copyright © 2017 castlabs. All rights reserved.
//

#import "ViewController.h"

#import <CastlabsSDK/CastlabsSDK.h>
#import <CastlabsSDK/CLPlayerViewController.h>

NSString* streamUrl = @"https://castlabs-dl.s3.amazonaws.com/public/Client/hls/hls-short-multiaudio-multisub/playlist.m3u8";

@interface ViewController  () {
	HLSDownloader* downloader;
	HLSDownload* download;
	NSTimer* timer;
	__weak IBOutlet UITextField *progressTextField;
}

@end

@implementation ViewController

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
	if (self = [super initWithCoder:aDecoder]) {
		downloader = [HLSDownloader sharedDownloader];
		// downloader = [[HLSDownloader alloc] initWithCellularAccess:YES];
		[CastlabsSDK with:@[]
			andLicenseKey:@""
			  andDelegate:nil];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	[self checkDownloadsStatus];
	NSNotificationCenter* center = [NSNotificationCenter defaultCenter];
	[center addObserver:self
			   selector:@selector(handleBecomeActive)
				   name:UIApplicationDidBecomeActiveNotification
				 object:nil];
	[center addObserver:self
			   selector:@selector(handleResignActive)
				   name:UIApplicationWillResignActiveNotification
				 object:nil];
}

-(void) handleResignActive {
	NSLog(@"handleResignActive");
	[timer invalidate];
}

-(void) handleBecomeActive {
	NSLog(@"handleBecomeActive");
	[self checkDownloadsStatus];
}

-(void) checkDownloadsStatus {
	[downloader getAllDownloads:^(NSDictionary *downloads) {
		// Handling simple case of a single ongoing/complete download
		// Discard any failed downlod
		for (HLSDownload* download in downloads.allValues) {
			if (download.state == HLSDownloadStateFailed) {
				continue;
			} else if (download.state == HLSDownloadStateCompleted) {
				[self updateStatusLabel];
			} else {
				NSLog(@"Found running download. Attaching timer to monitor progress");
				[self attachListenerToCurrentDownload];
			}
		}
		if (downloads.count > 0) {
			download = downloads.allValues[0];
			
		}
	}];
}

- (void)startDownload {
	UIActivityIndicatorView * loadingView = [self showActivityIndicatorOnView:self.view];
	// Load the available HLS tracks by creating an HLSDownloadRequest
	[downloader createDownloadRequest:[NSURL URLWithString:streamUrl]
					 drmConfiguration:nil
                             userMeta:nil
                 andCompletionHandler:^(HLSDownloadRequest *downloadRequest, NSError* err) {
						[loadingView stopAnimating];
						   if (downloadRequest) {
							   // Select one audio and one subtitle track.
							   // If no tracks are selected, the default audio track and NO subtitle track will be downloaded
							   // For instance, here we select the 1st audio track and the 1st subtitle track
							   [downloadRequest selectAudioOption:downloadRequest.audioTracks.options[0]];
							   [downloadRequest selectSubtitleOption:downloadRequest.subtitleTracks.options[0]];
							   
                               // From v3.4.3 we can request additional tracks to be downloaded
                               if (@available(iOS 11.0, *)) {
                                   [downloadRequest addAudioOption:downloadRequest.audioTracks.options[1]];
                                   [downloadRequest addSubtitleOption:downloadRequest.subtitleTracks.options[1]];
                               }
                               
                               
							   // Start the download.
							   // This method will return an HLSDownload object that can
							   // be used to track the download status and progress.
							[downloader startDownload:downloadRequest withHandler:^(HLSDownload * _download, NSError* err) {
								download = _download;
								[self attachListenerToCurrentDownload];
							   }];
						   } else {
							   NSLog(@"Failed to create download request");
						   }
					   }];
}

-(void) attachListenerToCurrentDownload {
	dispatch_async(dispatch_get_main_queue(), ^{
		timer = [NSTimer scheduledTimerWithTimeInterval:1.0/4.0
												 target:self
											   selector:@selector(updateStatusLabel)
											   userInfo:nil
												repeats:YES];
		[timer fire];
	});
}

- (void) updateStatusLabel {
	dispatch_async(dispatch_get_main_queue(), ^{
        NSString* status;
        if (download.state == HLSDownloadStateFailed) {
            status = @"Failed. ";
            [timer invalidate];
        } else if (download.state == HLSDownloadStateCompleted) {
            status = @"Completed. ";
            [timer invalidate];
        } else {
            if (download.state == HLSDownloadStateSuspended) {
                status = @"Paused. ";
            } else if (download.state == HLSDownloadStateRunning) {
                status = @"Running. ";
            }
            if (download.isMinSetDownloaded && download.isAdditionalTracksRequested) {
               status = [status stringByAppendingString: @" Downloading Additional Tracks"];
            } else {
                double progressPercentage = download.downloadedContentSize/download.expectedContentSize;
                if (isnan(progressPercentage)) {
                    progressPercentage = 0.0;
                }
                progressPercentage *= 100;
                status = [status stringByAppendingString:[NSString stringWithFormat: @"%3.1f%% [%.0f/%.0f]" ,
                                                          progressPercentage, download.downloadedContentSize, download.expectedContentSize ]];
            }
        }
        // Do not update status if it didn't change
        static NSString* _prevStat = nil;
        if (![_prevStat isEqualToString:status]) {
            [progressTextField setText:status];
            NSLog(@"Status: %@.", status);
            _prevStat = status;
        }
	});
}

-(void) playStream:(NSString*) url {
	UIStoryboard *sdkStoryboard = [UIStoryboard storyboardWithName:@"CLSDKStoryboard"
															bundle:[NSBundle bundleWithIdentifier:@"castlabs.CastlabsSDK"]];
	CLPlayerViewController *vc = [sdkStoryboard instantiateViewControllerWithIdentifier:@"CLPlayerViewController"];
	vc.streamUrl = url;
	[self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)onDowloadBtn:(id)sender {
	[self startDownload];
}

- (IBAction)onPauseBtn:(id)sender {
	[downloader suspend:download];
}

- (IBAction)onResumeBtn:(id)sender {
	[downloader resume:download];
}

- (IBAction)onCancelDownload:(id)sender {
	[downloader cancel:download];
	
	dispatch_async(dispatch_get_main_queue(), ^{
		[timer invalidate];
	});
	[progressTextField setText:@""];
}

- (IBAction)onPlayLocalBtn:(id)sender {
	
	NSString* localPath = [NSString stringWithFormat:@"%@/%@", NSHomeDirectory(), download.destinationPath];
	[self playStream:localPath];
}

- (IBAction)onPlayRemoteBtn:(id)sender {
	[self playStream:streamUrl];
}

- (IBAction)onRemoveStreamBtn:(id)sender {
	[downloader remove:download];
}

- (UIActivityIndicatorView *)showActivityIndicatorOnView:(UIView*)aView {
	CGSize viewSize = aView.bounds.size;
	UIActivityIndicatorView *activityIndicatorView = [[UIActivityIndicatorView alloc]
													  initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	activityIndicatorView.bounds = CGRectMake(0, 0, 65, 65);
	activityIndicatorView.hidesWhenStopped = YES;
	activityIndicatorView.alpha = 0.7f;
	activityIndicatorView.backgroundColor = [UIColor blackColor];
	activityIndicatorView.layer.cornerRadius = 10.0f;
	activityIndicatorView.center = CGPointMake(viewSize.width / 2.0, viewSize.height / 2.0);
	[aView addSubview:activityIndicatorView];
	[activityIndicatorView startAnimating];
	return activityIndicatorView;
}

@end
