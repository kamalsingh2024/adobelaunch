//
//  ViewController.h
//  TestHLSOffline
//
//  Copyright © 2017 castlabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

