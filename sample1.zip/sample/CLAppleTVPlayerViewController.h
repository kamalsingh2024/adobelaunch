//
//  CLAppleTVPlayerViewController.h
//  CastlabsSDK
//
//  Created by Emil Pettersson on 25/01/16.
//  Copyright © 2016 castLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CastlabsTVSDK/CastlabsTVSDK.h"

@class CLDrmConfiguration;
typedef NS_ENUM(NSUInteger, CLContentType);

@protocol CLAppleTVPlayerViewControllerDelegate <NSObject>
@optional
- (nullable NSData *) getCKC:(nullable NSData *)keyServerResponse;
- (nullable NSString *) getSPCMessageToKeyServer:(nullable NSString *)spcData;

/// @brief Called when a player is seeking.
/// @param position The new progress position.

- (void) onSeekingTo:(CMTime)position;

/// @brief Called immediately before CLAppleTVPlayerViewController is dismissed.
/// @param position The progress position at time of dismissing.
- (void) willDismissWithPosition:(CMTime)position;

/// @brief Called when the menu is showing.
- (void) onMenuPanelShown;

/// @brief Called when the menu is hiding.
- (void) onMenuPanelDismiss;

@end

/*!
 @interface CLAppleTVPlayerViewController
 
 @brief Sample ViewController for AppleTV using castLabs player
 
 @discussion It can be used to launch the player in full-screen mode. The source code of this class is provided to SDK customer as part of the bundle.
 
 @author Emil Pettersson
 @copyright  Copyright © 2016 castLabs
 */
@interface CLAppleTVPlayerViewController : UIViewController

@property (nullable, nonatomic, weak) id<CLAppleTVPlayerViewControllerDelegate> delegate;

/// Stream url to be played
@property(nonnull, nonatomic) NSString* streamUrl;

/// DRM configuration should be provied for encrypted files
@property(nullable, nonatomic) CLDrmConfiguration* drmConfiguration;

/// The player can guess the protocol type from the stream URL but you can also set it explicitely with this property
@property(nonatomic) CLContentType contentType;


@property(nullable, nonatomic, readonly) id<CLPlayer> player;

@end
